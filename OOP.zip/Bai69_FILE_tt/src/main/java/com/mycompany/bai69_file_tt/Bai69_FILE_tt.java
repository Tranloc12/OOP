/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai69_file_tt;

/**
 *
 * @author admin
 */
public class Bai69_FILE_tt {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
