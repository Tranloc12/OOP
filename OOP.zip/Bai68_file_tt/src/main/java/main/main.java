/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class main {

    File file;

    public main(String tenFile) {
        this.file = new File(tenFile);
    }

    public boolean kiemTraThucThi() {
        return this.file.canExecute();
    }

    public boolean kiemTraDoc() {
        return this.file.canRead();
    }

    public boolean kiemTraGhi() {
        return this.file.canWrite();
    }

    public void inDuongDuong() {
        System.out.println(this.file.getAbsolutePath());
    }

    public void inTen() {
        System.out.println(this.file.getName());
    }

    public void kiemTraThuMucHoaTapTin() {
        if (this.file.isDirectory()) {
            System.out.println("thu muc");
        } else {
            System.out.println("tap tin");
        }
    }
public void inDanhSachCacFileCon()
{
    if(this.file.isDirectory())
    {
        System.out.println("cac tap tin con /thu muc con");
        File[] mangCon= this.file.listFiles();
        for(File file: mangCon)
        {
            System.out.println(file.getAbsolutePath());
        }
    }
    else if(this.file.isFile())
    {
        System.out.println("day la tap tin khong co d lieu ben trong ");
    }
}

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int luachon = 0;
        System.out.println("nhao ten file:");
        String tenFile = sc.nextLine();
        main vdf = new main(tenFile);
        do {
            System.err.println("-----MENU----");
            System.out.println("1 kiem tra file co the thuc thi: ");
            System.out.println("2.kiem tra file có the doc:");
            System.out.println("3.kiem tra file co the ghi: ");
            System.out.println("4.in duong dan: ");
            System.out.println("5.in te file: ");
            System.out.println("6 kiem tra file la thu muc hoac tap tin: ");
            System.out.println("7.in ra danh sach cac file con: ");
            System.out.println("8.in ra cay thu muc: ");
            System.out.println("0.thoat");
            System.out.println("vui long chon");
            luachon = sc.nextInt();
            switch (luachon) {
                case 1:
                    System.out.println("kiem tra co thi thuc thi" + vdf.kiemTraThucThi());
                    break;
                case 2:
                    System.out.println("kiem tra co thi doc" + vdf.kiemTraDoc());
                    break;
                case 3:
                    System.out.println("kiem tra co thi ghi" + vdf.kiemTraGhi());
                    break;
                case 4:
                    vdf.inDuongDuong();
                    break;
                case 5:
                    vdf.inTen();
                    break;
                case 6:
                    vdf.kiemTraThuMucHoaTapTin();
                    break;
                case 7:
                    vdf.inDanhSachCacFileCon();
                    break;
                case 8:
                   

                default:
                    throw new AssertionError();
            }
        } while (luachon != 0);
    }
}
