/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {
    public static void main(String[] args) {
        ConNguoi2 cn= new ConNguoi2("tttt",2021);
        cn.an();
        cn.ngu();
        cn.uong();
        
        HocSinh2 hs= new HocSinh2("tttt","Lop1","Truong1",2021);
        hs.an();
        hs.lamBaiTap();
    }
   
}