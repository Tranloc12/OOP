/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author admin
 */
public class HocSinh2 extends ConNguoi2 {
    private String tenLop,tenTruong;
    
    public HocSinh2(String tenLop, String tenTruong, String hoVaTen, int namSinh) {
        super(hoVaTen, namSinh);
        this.tenLop = tenLop;
        this.tenTruong = tenTruong;
    }

    public String getTenLop() {
        return tenLop;
    }

    public String getTenTruong() {
        return tenTruong;
    }

    public void setTenLop(String tenLop) {
        this.tenLop = tenLop;
    }

    public void setTenTruong(String tenTruong) {
        this.tenTruong = tenTruong;
    }
    public void lamBaiTap(){
        System.out.println("hang ngay");
    }

   
    
}
