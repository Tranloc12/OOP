/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class dog extends DongVat {
    
    public dog(String name) {
        super(name);
    }
    public void bark()
    {
        System.out.println("gau gau ");
    }
    
}
