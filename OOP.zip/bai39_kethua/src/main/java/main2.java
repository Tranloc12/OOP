/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main2 {
    public static void main(String[] args) {
        dog d= new dog("dog");
        d.eat();
        d.bark();
        BabyDog bd= new BabyDog("Babydog");
        bd.eat();
        bd.bark();
        bd.weep();
        
    }
}
