/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;


/**
 *
 * @author admin
 */
public class Main1 {
    public static void main(String[] args) throws ParseException {
        QuanLyCongDan qlcd = new QuanLyCongDan();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        CongDan cd1 = new CongDan("123456", "A", dateFormat.parse("01/01/1990"));
        CongDan cd2 = new CongDan("789012", "B", dateFormat.parse("21/01/2004"));
        qlcd.themcd(cd1, cd2);
        System.out.println(cd1);
        System.out.println(cd2);
        CongDanNuocNgoai cdnn = new CongDanNuocNgoai("345678", "C","A", dateFormat.parse("21/01/2004"));
        qlcd.themcd(cdnn);
        System.out.println(cdnn);

        System.out.println("Danh sach cong dan nuoc ngoai:");
        for (CongDan cd : qlcd.timcdnn()) {
            System.out.println(cd.getHoTen());
        }

        Vacxin vacxin1 = new Vacxin("Covid-19", "USA");
        Vacxin vacxin2 = new Vacxin("Flu", "UK");

        TiemChung tiemChung = new TiemChung();
        tiemChung.ghiNhanTiem(vacxin1, cd1, "Bệnh viện A");
        tiemChung.ghiNhanTiem(vacxin2, cd1, "Bệnh viện B");
        
        
    }      
}

