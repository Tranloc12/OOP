/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuanLyVacXin {
    private List<Vacxin> ds= new ArrayList<>();
    public void themVacXin(Vacxin... vx)
    {
        getDs().addAll(Arrays.asList(vx));
    }
    public void sapXep()
    {
        this.getDs().sort(Comparator.comparing(Vacxin::getXuatXu).thenComparing(Vacxin::soLuong));
    }

    /**
     * @return the ds
     */
    public List<Vacxin> getDs() {
        return ds;
    }

    /**
     * @param ds the ds to set
     */
    public void setDs(List<Vacxin> ds) {
        this.ds = ds;
    }
    
}
