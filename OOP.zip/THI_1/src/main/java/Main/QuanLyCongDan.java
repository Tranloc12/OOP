/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author admin
 */
public class QuanLyCongDan {
    private List<CongDan> ds= new ArrayList<>();
    public void themcd(CongDan... cd)
    {
        getDs().addAll(Arrays.asList(cd));
        
    }

    public List<CongDan> timcdnn()
    {
        return this.getDs().stream().filter(c->c instanceof CongDanNuocNgoai).collect(Collectors.toList());
    }
    public List<CongDan> tiem2muitrolen()
    {
        return this.getDs().stream().filter(c->c.getTc().size()>= 2).collect(Collectors.toList());
    }

    /**
     * @return the ds
     */
    public List<CongDan> getDs() {
        return ds;
    }

    /**
     * @param ds the ds to set
     */
    public void setDs(List<CongDan> ds) {
        this.ds = ds;
    }
 }
