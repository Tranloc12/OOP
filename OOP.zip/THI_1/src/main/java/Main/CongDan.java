/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 *
 * @author admin
 */
public class CongDan {
    private String cccd;
    private String hoTen;
    private Date ngaySinh;
    private List<TiemChung> tc;
    

    public CongDan(String cccd, String hoTen, Date ngaySinh)  {
        this.cccd = cccd;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.tc= new ArrayList<>();
    }

    @Override
    public String toString() {
        return "CongDan" + "\ncccd=" + cccd + "\nhoTen=" + hoTen + "\nngaySinh=" + ngaySinh + "\ntc=" + tc + " ";
    }

 
    
    public boolean isTiem()
    {
        Date d = new Date();
        if(this.tc.isEmpty())
        
            return d.getYear()- this.ngaySinh.getYear()>=18;
        
        Calendar cl=this.tc.get(this.tc.size() -1 ).getNgayTiem();
        cl.add(Calendar.MONTH, 3);
        Calendar cld= new GregorianCalendar();
        return cld.compareTo(cl)>=0;
    }
    

    public String getCccd() {
        return cccd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    /**
     * @return the tc
     */
    public List<TiemChung> getTc() {
        return tc;
    }

    /**
     * @param tc the tc to set
     */
    public void setTc(List<TiemChung> tc) {
        this.tc = tc;
    }
    
    
}
