/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class VeThang extends VeXe{
    private int thangCoHieuLuc;
    private int ngayMuaCuaThang;
    private double giaVe;

    public VeThang(int thangCoHieuLuc, int ngayMuaCuaThang, SinhVien sinhVien, String diaDiemXuatPhat) {
        super(sinhVien, diaDiemXuatPhat);
        this.thangCoHieuLuc = thangCoHieuLuc;
        this.ngayMuaCuaThang = ngayMuaCuaThang;
        if(ngayMuaCuaThang<15)
        this.giaVe = 450000;
        else this.giaVe=350000;
    }

    @Override
    public String toString() {
        return super.toString()+"thang co hieu luc: "+thangCoHieuLuc+"\nngay mua: "+ngayMuaCuaThang+"\ngia ve: "+giaVe+"/thang\n"; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
  
            
            

    /**
     * @return the thangCoHieuLuc
     */
    public int getThangCoHieuLuc() {
        return thangCoHieuLuc;
    }

    /**
     * @param thangCoHieuLuc the thangCoHieuLuc to set
     */
    public void setThangCoHieuLuc(int thangCoHieuLuc) {
        this.thangCoHieuLuc = thangCoHieuLuc;
    }

    /**
     * @return the ngayMuaCuaThang
     */
    

    /**
     * @return the giaVe
     */
    public double getGiaVe() {
        return giaVe;
    }

    /**
     * @param giaVe the giaVe to set
     */
    public void setGiaVe(double giaVe) {
        this.giaVe = giaVe;
    }

    /**
     * @return the ngayMuaCuaThang
     */
    public int getNgayMuaCuaThang() {
        return ngayMuaCuaThang;
    }

    /**
     * @param ngayMuaCuaThang the ngayMuaCuaThang to set
     */
    public void setNgayMuaCuaThang(int ngayMuaCuaThang) {
        this.ngayMuaCuaThang = ngayMuaCuaThang;
    }

    
    
    
}
