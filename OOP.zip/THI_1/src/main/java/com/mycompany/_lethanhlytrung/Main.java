/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

/**
 *
 * @author admin
 */
import java.util.*;
import java.text.SimpleDateFormat;

class Student {
    private String mssv;
    private String hoTen;
    private Date ngaySinh;
    private String gioiTinh;
    private String khoa;

    public Student(String mssv, String hoTen, Date ngaySinh, String gioiTinh, String khoa) {
        this.mssv = mssv;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.khoa = khoa;
    }

    public String getMssv() {
        return mssv;
    }

    public String getHoTen() {
        return hoTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public String getKhoa() {
        return khoa;
    }
}

abstract class Ticket {
    private String maVe;
    private Student sinhVien;
    private String diemXuatPhat;

    public Ticket(Student sinhVien, String diemXuatPhat) {
        this.maVe = UUID.randomUUID().toString().substring(0, 8);
        this.sinhVien = sinhVien;
        this.diemXuatPhat = diemXuatPhat;
    }

    public String getMaVe() {
        return maVe;
    }

    public Student getSinhVien() {
        return sinhVien;
    }

    public String getDiemXuatPhat() {
        return diemXuatPhat;
    }

    public abstract double getGiaVe();
}

class AnnualTicket extends Ticket {
    private int namHieuLuc;
    private Date ngayMua;
    private double giaVe;

    public AnnualTicket(Student sinhVien, String diemXuatPhat, int namHieuLuc, Date ngayMua) {
        super(sinhVien, diemXuatPhat);
        this.namHieuLuc = namHieuLuc;
        this.ngayMua = ngayMua;
        this.giaVe = ngayMua.getMonth() < 5 ? 4500000 : 3000000;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public int getNamHieuLuc() {
        return namHieuLuc;
    }

    public Date getNgayMua() {
        return ngayMua;
    }
}

class MonthlyTicket extends Ticket {
    private int thangHieuLuc;
    private int namHieuLuc;
    private Date ngayMua;
    private double giaVe;

    public MonthlyTicket(Student sinhVien, String diemXuatPhat, int thangHieuLuc, int namHieuLuc, Date ngayMua) {
        super(sinhVien, diemXuatPhat);
        this.thangHieuLuc = thangHieuLuc;
        this.namHieuLuc = namHieuLuc;
        this.ngayMua = ngayMua;
        this.giaVe = ngayMua.getDate() < 15 ? 450000 : 300000;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public int getThangHieuLuc() {
        return thangHieuLuc;
    }

    public int getNamHieuLuc() {
        return namHieuLuc;
    }

    public Date getNgayMua() {
        return ngayMua;
    }
}

class DailyTicket extends Ticket {
    private Date ngayDi;
    private double giaVe = 20000;

    public DailyTicket(Student sinhVien, String diemXuatPhat, Date ngayDi) {
        super(sinhVien, diemXuatPhat);
        this.ngayDi = ngayDi;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public Date getNgayDi() {
        return ngayDi;
    }
}

class OUBusSystem {
    private List<Student> danhSachSinhVien = new ArrayList<>();
    private List<Ticket> danhSachVe = new ArrayList<>();

    public void themSinhVien(Student sinhVien) {
        danhSachSinhVien.add(sinhVien);
    }

    public void hienThiThongTinVe() {
        System.out.println("1. Vé năm: 4.5 triệu/năm nếu mua trước tháng 6, 3 triệu/năm nếu mua sau tháng 6");
        System.out.println("2. Vé tháng: 450k/tháng nếu mua trước ngày 15, 300k/tháng nếu mua sau ngày 15");
        System.out.println("3. Vé ngày: 20k/ngày");
    }

    public Ticket muaVe(Student sinhVien, String loaiVe, String diemXuatPhat, int namHieuLuc, int thangHieuLuc, Date ngayMua, Date ngayDi) {
        Ticket ve = null;
        switch (loaiVe) {
            case "nam":
                ve = new AnnualTicket(sinhVien, diemXuatPhat, namHieuLuc, ngayMua);
                break;
            case "thang":
                ve = new MonthlyTicket(sinhVien, diemXuatPhat, thangHieuLuc, namHieuLuc, ngayMua);
                break;
            case "ngay":
                ve = new DailyTicket(sinhVien, diemXuatPhat, ngayDi);
                break;
            default:
                throw new IllegalArgumentException("Loại vé không hợp lệ");
        }
        danhSachVe.add(ve);
        return ve;
    }

    public boolean kiemTraVe(String maVe) {
        for (Ticket ve : danhSachVe) {
            if (ve.getMaVe().equals(maVe)) {
                return true;
            }
        }
        return false;
    }

    public void thongKeVeTheoLoai(Student sinhVien) {
        int soLuongVeNam = 0;
        int soLuongVeThang = 0;
        int soLuongVeNgay = 0;

        for (Ticket ve : danhSachVe) {
            if (ve.getSinhVien().equals(sinhVien)) {
                if (ve instanceof AnnualTicket) {
                    soLuongVeNam++;
                } else if (ve instanceof MonthlyTicket) {
                    soLuongVeThang++;
                } else if (ve instanceof DailyTicket) {
                    soLuongVeNgay++;
                }
            }
        }

        System.out.println("Sinh viên " + sinhVien.getHoTen() + " đã mua " + soLuongVeNam + " vé năm, " + soLuongVeThang + " vé tháng, " + soLuongVeNgay + " vé ngày");
    }

    public List<Student> timSinhVienTheoDiemVaNgay(String diemXuatPhat, Date ngayDi) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String ngayDiFormatted = sdf.format(ngayDi);
        List<Student> ketQua = new ArrayList<>();

        for (Ticket ve : danhSachVe) {
            if (ve instanceof DailyTicket && ve.getDiemXuatPhat().equals(diemXuatPhat) && sdf.format(((DailyTicket) ve).getNgayDi()).equals(ngayDiFormatted)) {
                ketQua.add(ve.getSinhVien());
            }
        }

        return ketQua;
    }

    public List<Student> sapXepSinhVienTheoSoLuongVe() {
        List<Student> sinhVienSapXep = new ArrayList<>(danhSachSinhVien);

        for (int i = 0; i < sinhVienSapXep.size() - 1; i++) {
            for (int j = i + 1; j < sinhVienSapXep.size(); j++) {
                Student s1 = sinhVienSapXep.get(i);
                Student s2 = sinhVienSapXep.get(j);

                int soLuongVeS1 = demSoLuongVe(s1);
                int soLuongVeS2 = demSoLuongVe(s2);

                if (soLuongVeS1 < soLuongVeS2 || (soLuongVeS1 == soLuongVeS2 && s1.getHoTen().compareTo(s2.getHoTen()) > 0)) {
                    Collections.swap(sinhVienSapXep, i, j);
                }
            }
        }
        return sinhVienSapXep;
    }

    private int demSoLuongVe(Student sinhVien) {
        int count = 0;
        for (Ticket ve : danhSachVe) {
            if (ve.getSinhVien().equals(sinhVien)) {
                count++;
            }
        }
        return count;
    }
}

public class Main {
    public static void main(String[] args) throws Exception {
        OUBusSystem heThong = new OUBusSystem();

        // Thêm một số sinh viên
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Student sinhVien1 = new Student("001", "Nguyen Van A", sdf.parse("2000-01-01"), "Nam", "CNTT");
        Student sinhVien2 = new Student("002", "Le Thi B", sdf.parse("2000-02-02"), "Nu", "Dien");
        heThong.themSinhVien(sinhVien1);
        heThong.themSinhVien(sinhVien2);

        // Hiển thị thông tin các loại vé
        heThong.hienThiThongTinVe();
        

        // Mua một số vé
        Ticket veNam = heThong.muaVe(sinhVien1, "nam", "Noi thanh", 2024, 0, sdf.parse("2024-05-10"), null);
        Ticket veThang = heThong.muaVe(sinhVien2, "thang", "Noi thanh", 2024, 5, sdf.parse("2024-05-14"), null);
        Ticket veNgay = heThong.muaVe(sinhVien1, "ngay", "Noi thanh", 0, 0, null, sdf.parse("2024-05-20"));

        // Kiểm tra vé
        System.out.println("Vé " + veNgay.getMaVe() + " hợp lệ: " + heThong.kiemTraVe(veNgay.getMaVe()));

        // Thống kê vé theo loại cho một sinh viên
        heThong.thongKeVeTheoLoai(sinhVien1);

        // Tìm sinh viên theo điểm xuất phát và ngày
        List<Student> sinhViens = heThong.timSinhVienTheoDiemVaNgay("Noi thanh", sdf.parse("2024-05-20"));
        System.out.println("Sinh viên mua vé xuất phát từ Nội thành vào ngày 2024-05-20:");
        for (Student sv : sinhViens) {
            System.out.println(sv.getHoTen());
        }

        // Sắp xếp sinh viên theo số lượng vé đã mua
        List<Student> sinhVienSapXep = heThong.sapXepSinhVienTheoSoLuongVe();
        System.out.println("Sinh viên sắp xếp theo số lượng vé đã mua:");
        for (Student sv : sinhVienSapXep) {
            System.out.println(sv.getHoTen());
        }
    }
}
