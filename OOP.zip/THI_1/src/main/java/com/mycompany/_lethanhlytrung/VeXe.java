/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

/**
 *
 * @author admin
 */
public abstract class VeXe {
    private static int dem=0;
    private String maVe;
    protected SinhVien sinhVien;
    private String diaDiemXuatPhat;

    public VeXe( SinhVien sinhVien, String diaDiemXuatPhat) {
        this.maVe =String.format("%03d",dem++) ;
        this.sinhVien = sinhVien;
        this.diaDiemXuatPhat = diaDiemXuatPhat;
        this.sinhVien.getDs().add(this);
    }

    @Override
    public String toString() {
        return "ma ve: "+maVe+"\ndai diem xuat phat: "+diaDiemXuatPhat+"\n";
    }
    
    /**
     * @return the maVe
     */
    public String getMaVe() {
        return maVe;
    }

    /**
     * @param maVe the maVe to set
     */
    public void setMaVe(String maVe) {
        this.maVe = maVe;
    }

    /**
     * @return the sinhVien
     */
    public SinhVien getSinhVien() {
        return sinhVien;
    }

    /**
     * @param sinhVien the sinhVien to set
     */
    public void setSinhVien(SinhVien sinhVien) {
        this.sinhVien = sinhVien;
    }

    /**
     * @return the diaDiemXuatPhat
     */
    public String getDiaDiemXuatPhat() {
        return diaDiemXuatPhat;
    }

    /**
     * @param diaDiemXuatPhat the diaDiemXuatPhat to set
     */
    public void setDiaDiemXuatPhat(String diaDiemXuatPhat) {
        this.diaDiemXuatPhat = diaDiemXuatPhat;
    }
    
}
