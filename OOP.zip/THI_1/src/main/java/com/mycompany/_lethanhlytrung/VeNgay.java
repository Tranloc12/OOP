/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

import java.time.LocalDate;


/**
 *
 * @author admin
 */
public class VeNgay extends VeXe{
    private LocalDate thongTinNgayDi;
    private double giaVe=20000;

    public VeNgay(String thongTinNgayDi, SinhVien sinhVien, String diaDiemXuatPhat) {
        super(sinhVien, diaDiemXuatPhat);
        this.thongTinNgayDi = LocalDate.parse(thongTinNgayDi,CauHinh.FORMATTER);
       
    }

    @Override
    public String toString() {
        return super.toString()+"thong tin ngay di: "+thongTinNgayDi+"\ngia ve: "+giaVe+"/ngay\n"; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     * @return the thongTinNgayDi
     */
    public LocalDate getThongTinNgayDi() {
        return thongTinNgayDi;
    }

    /**
     * @param thongTinNgayDi the thongTinNgayDi to set
     */
    public void setThongTinNgayDi(LocalDate thongTinNgayDi) {
        this.thongTinNgayDi = thongTinNgayDi;
    }

    /**
     * @return the giaVe
     */
    public double getGiaVe() {
        return giaVe;
    }

    /**
     * @param giaVe the giaVe to set
     */
    public void setGiaVe(double giaVe) {
        this.giaVe = giaVe;
    }

   
    
}
