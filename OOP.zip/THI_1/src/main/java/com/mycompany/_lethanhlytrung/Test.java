/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany._lethanhlytrung;

/**
 *
 * @author admin
 */
public class Test {

    public static void main(String[] args) {
        SinhVien sv1= new SinhVien("A01", "Le Thi A","20/01/2004", GioiTinh.GIOI_TINH_NU, "Khoa CNTT");
        SinhVien sv2= new SinhVien("A02", "Le Thi B","21/01/2004", GioiTinh.GIOI_TINH_NU, "Khoa Kinh Te");
        SinhVien sv3= new SinhVien("A03", "Nguyen Van A", "22/01/2004", GioiTinh.GIOi_TINH_NAM, "Khoa Luat");
        SinhVien sv4= new SinhVien("A04", "Nguyen Van b", "23/01/2004", GioiTinh.GIOi_TINH_NAM, "Khoa CNTT");
        VeXe vx1 =new VeNgay("19/01/2023",sv4, "Ha Noi");
        VeXe vx2 = new VeThang(6, 16, sv1, "TP HCM");
        VeXe vx3 = new VeThang(6, 3, sv4, "Ha Noi");
        VeXe vx4 = new VeNam(1, 7, sv2, "Cao Bang");
        VeXe vx5 = new VeNam(1, 1, sv3, "Cao Bang");
        VeXe vx6 =new VeNgay("19/01/2023", sv4, "Ha Noi");
        VeXe vx7=new VeNgay("19/01/2023", sv4, "Ha Noi");
        VeXe vx8 =new VeNgay("19/01/2023", sv1, "Ha Noi");
        QuanLyVe ql =new QuanLyVe();
        ql.themSinhVien(sv1,sv2,sv3,sv4);
        ql.themVeXe(vx1,vx2,vx3,vx4,vx5,vx6,vx7,vx8);
        
        System.out.println(vx2);
        ql.timSinhVien("20/01/2023").forEach(h->System.out.println(h));

        

    }
}
