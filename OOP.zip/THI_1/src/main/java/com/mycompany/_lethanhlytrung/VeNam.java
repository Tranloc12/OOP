/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class VeNam extends VeXe{
    private int namCoHieuLuc;
    private int thangMuaCuaNam;
    private double giaVe;
    public VeNam(int namCoHieuLuc, int thangMua, SinhVien sinhVien, String diaDiemXuatPhat) {
        super(sinhVien, diaDiemXuatPhat);
        this.namCoHieuLuc = namCoHieuLuc;
        this.thangMuaCuaNam = thangMua;
          if(thangMua<6)
            this.giaVe=4500000;
          else this.giaVe=3000000;
    }

    @Override
    public String toString() {
        return super.toString() + "nam co hieu luc: "+namCoHieuLuc+"\nthang mua: "+thangMuaCuaNam+"\ngia ve: "+giaVe+"/nam\n" ; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    /**
     * @return the namCoHieuLuc
     */
    public int getNamCoHieuLuc() {
        return namCoHieuLuc;
    }

    /**
     * @param namCoHieuLuc the namCoHieuLuc to set
     */
    public void setNamCoHieuLuc(int namCoHieuLuc) {
        this.namCoHieuLuc = namCoHieuLuc;
    }

    /**
     * @return the thangMuaCuaNam
     */
    

    /**
     * @return the giaVe
     */
    public double getGiaVe() {
        return giaVe;
    }

    /**
     * @param giaVe the giaVe to set
     */
    public void setGiaVe(double giaVe) {
        this.giaVe = giaVe;
    }

    /**
     * @return the thangMuaCuaNam
     */
    public int getThangMuaCuaNam() {
        return thangMuaCuaNam;
    }

    /**
     * @param thangMuaCuaNam the thangMuaCuaNam to set
     */
    public void setThangMuaCuaNam(int thangMuaCuaNam) {
        this.thangMuaCuaNam = thangMuaCuaNam;
    }
    
    
}
