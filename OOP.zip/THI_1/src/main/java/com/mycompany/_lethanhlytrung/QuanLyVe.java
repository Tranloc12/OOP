/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author admin
 */
public class QuanLyVe {
        private List<VeXe> vx = new ArrayList<>();
        private List<SinhVien> sv= new ArrayList<>();
        
        public void themVeXe(VeXe... v){
            vx.addAll(Arrays.asList(v));      
        }
        public List<VeXe> xuatThongtinVe(String kw){
           return vx.stream().filter(h->h.getMaVe().equals(kw)).collect(Collectors.toList());
        }
        public void themSinhVien(SinhVien v){
            sv.add(v);
        }
        public void themSinhVien(SinhVien... a){
            sv.addAll(Arrays.asList(a));
        }
        public void hienthi(){
            sv.forEach(h->System.out.println(h));
        }
        public List<SinhVien> timSinhVien(String kw){
           return sv.stream().filter(h->h.getDs().contains(kw)).collect(Collectors.toList());
        }
        public List<VeXe> hienThiDanhSachVeCacLoai(String kw){
           return sv.stream().filter(h->h.getMaSoSinhVien().equals(kw)).flatMap(h->h.getDs().stream()).collect(Collectors.toList());
        }
        
}

