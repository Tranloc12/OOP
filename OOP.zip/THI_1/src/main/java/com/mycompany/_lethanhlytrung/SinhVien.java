/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany._lethanhlytrung;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class SinhVien {
   private String maSoSinhVien;
   private String hoTen;
   private LocalDate ngaySinh;
   private GioiTinh gioiTinh;
   private String khoaTrucThuoc;
   private List<VeXe> ds = new ArrayList<>();

    public SinhVien(String maSoSinhVien, String hoTen, String ngaySinh, GioiTinh gioiTinh, String khoaTrucThuoc) {
        this.maSoSinhVien = maSoSinhVien;
        this.hoTen = hoTen;
        this.ngaySinh = LocalDate.parse(ngaySinh, CauHinh.FORMATTER);
        this.gioiTinh = gioiTinh;
        this.khoaTrucThuoc = khoaTrucThuoc;
    }
    public int soLuongVeMua(){
        return ds.size();
    }
    public void xuatVe(){
        ds.forEach(h->System.out.println(h));
    }
    @Override
    public String toString() {
        return "MSSV: "+maSoSinhVien+"\nho ten: "+hoTen+"\nngay sinh: "+ngaySinh.format(CauHinh.FORMATTER)+"\ngioi tinh: "+gioiTinh.getGioiTinh()+"\nKhoa: "+khoaTrucThuoc;
    }
 
    /**
     * @return the maSoSinhVien
     */
    public String getMaSoSinhVien() {
        return maSoSinhVien;
    }

    /**
     * @param maSoSinhVien the maSoSinhVien to set
     */
    public void setMaSoSinhVien(String maSoSinhVien) {
        this.maSoSinhVien = maSoSinhVien;
    }

    /**
     * @return the hoTen
     */
    public String getHoTen() {
        return hoTen;
    }

    /**
     * @param hoTen the hoTen to set
     */
    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    /**
     * @return the ngaySinh
     */
    public LocalDate getNgaySinh() {
        return ngaySinh;
    }

    /**
     * @param ngaySinh the ngaySinh to set
     */
    public void setNgaySinh(LocalDate ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    /**
     * @return the gioiTinh
     */
    public GioiTinh getGioiTinh() {
        return gioiTinh;
    }

    /**
     * @param gioiTinh the gioiTinh to set
     */
    public void setGioiTinh(GioiTinh gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    /**
     * @return the khoaTrucThuoc
     */
    public String getKhoaTrucThuoc() {
        return khoaTrucThuoc;
    }

    /**
     * @param khoaTrucThuoc the khoaTrucThuoc to set
     */
    public void setKhoaTrucThuoc(String khoaTrucThuoc) {
        this.khoaTrucThuoc = khoaTrucThuoc;
    }

    public void setDs(List<VeXe> ds) {
        this.ds = ds;
    }

    public List<VeXe> getDs() {
        return ds;
    }


   
   
}
