/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

/**
 *
 * @author admin
 */

import java.util.*;
import java.text.SimpleDateFormat;

class Student {
    private String mssv;
    private String hoTen;
    private Date ngaySinh;
    private String gioiTinh;
    private String khoa;

    public Student(String mssv, String hoTen, Date ngaySinh, String gioiTinh, String khoa) {
        this.mssv = mssv;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.khoa = khoa;
    }

    public String getMssv() {
        return mssv;
    }

    public String getHoTen() {
        return hoTen;
    }

    public Date getNgaySinh() {
        return ngaySinh;
    }

    public String getGioiTinh() {
        return gioiTinh;
    }

    public String getKhoa() {
        return khoa;
    }
}

abstract class Ticket {
    private String maVe;
    private Student sinhVien;
    private String diemXuatPhat;

    public Ticket(Student sinhVien, String diemXuatPhat) {
        this.maVe = UUID.randomUUID().toString().substring(0, 8);
        this.sinhVien = sinhVien;
        this.diemXuatPhat = diemXuatPhat;
    }

    public String getMaVe() {
        return maVe;
    }

    public Student getSinhVien() {
        return sinhVien;
    }

    public String getDiemXuatPhat() {
        return diemXuatPhat;
    }

    public abstract double getGiaVe();
}

class AnnualTicket extends Ticket {
    private int namHieuLuc;
    private Date ngayMua;
    private double giaVe;

    public AnnualTicket(Student sinhVien, String diemXuatPhat, int namHieuLuc, Date ngayMua) {
        super(sinhVien, diemXuatPhat);
        this.namHieuLuc = namHieuLuc;
        this.ngayMua = ngayMua;
        this.giaVe = ngayMua.getMonth() < 5 ? 4500000 : 3000000;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public int getNamHieuLuc() {
        return namHieuLuc;
    }

    public Date getNgayMua() {
        return ngayMua;
    }
}

class MonthlyTicket extends Ticket {
    private int thangHieuLuc;
    private int namHieuLuc;
    private Date ngayMua;
    private double giaVe;

    public MonthlyTicket(Student sinhVien, String diemXuatPhat, int thangHieuLuc, int namHieuLuc, Date ngayMua) {
        super(sinhVien, diemXuatPhat);
        this.thangHieuLuc = thangHieuLuc;
        this.namHieuLuc = namHieuLuc;
        this.ngayMua = ngayMua;
        this.giaVe = ngayMua.getDate() < 15 ? 450000 : 300000;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public int getThangHieuLuc() {
        return thangHieuLuc;
    }

    public int getNamHieuLuc() {
        return namHieuLuc;
    }

    public Date getNgayMua() {
        return ngayMua;
    }
}

class DailyTicket extends Ticket {
    private Date ngayDi;
    private double giaVe = 20000;

    public DailyTicket(Student sinhVien, String diemXuatPhat, Date ngayDi) {
        super(sinhVien, diemXuatPhat);
        this.ngayDi = ngayDi;
    }

    @Override
    public double getGiaVe() {
        return giaVe;
    }

    public Date getNgayDi() {
        return ngayDi;
    }
}

class OUBusSystem {
    private List<Student> danhSachSinhVien = new ArrayList<>();
    private List<Ticket> danhSachVe = new ArrayList<>();

    public void themSinhVien(Student sinhVien) {
        danhSachSinhVien.add(sinhVien);
    }

    public void hienThiThongTinVe() {
        System.out.println("1. Vé năm: 4.5 triệu/năm nếu mua trước tháng 6, 3 triệu/năm nếu mua sau tháng 6");
        System.out.println("2. Vé tháng: 450k/tháng nếu mua trước ngày 15, 300k/tháng nếu mua sau ngày 15");
        System.out.println("3. Vé ngày: 20k/ngày");
    }

    public Ticket muaVe(Student sinhVien, String loaiVe, Map<String, Object> params) {
        Ticket ve = null;
        switch (loaiVe) {
            case "nam":
                ve = new AnnualTicket(sinhVien, (String)params.get("diemXuatPhat"), (int)params.get("namHieuLuc"), (Date)params.get("ngayMua"));
                break;
            case "thang":
                ve = new MonthlyTicket(sinhVien, (String)params.get("diemXuatPhat"), (int)params.get("thangHieuLuc"), (int)params.get("namHieuLuc"), (Date)params.get("ngayMua"));
                break;
            case "ngay":
                ve = new DailyTicket(sinhVien, (String)params.get("diemXuatPhat"), (Date)params.get("ngayDi"));
                break;
            default:
                throw new IllegalArgumentException("Loại vé không hợp lệ");
        }
        danhSachVe.add(ve);
        return ve;
    }

    public boolean kiemTraVe(String maVe) {
        return danhSachVe.stream().anyMatch(ve -> ve.getMaVe().equals(maVe));
    }

    public Map<String, Integer> thongKeVeTheoLoai(Student sinhVien) {
        int soLuongVeNam = (int) danhSachVe.stream().filter(ve -> ve instanceof AnnualTicket && ve.getSinhVien().equals(sinhVien)).count();
        int soLuongVeThang = (int) danhSachVe.stream().filter(ve -> ve instanceof MonthlyTicket && ve.getSinhVien().equals(sinhVien)).count();
        int soLuongVeNgay = (int) danhSachVe.stream().filter(ve -> ve instanceof DailyTicket && ve.getSinhVien().equals(sinhVien)).count();
        Map<String, Integer> thongKe = new HashMap<>();
        thongKe.put("nam", soLuongVeNam);
        thongKe.put("thang", soLuongVeThang);
        thongKe.put("ngay", soLuongVeNgay);
        return thongKe;
    }

    public List<Student> timSinhVienTheoDiemVaNgay(String diemXuatPhat, Date ngayDi) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String ngayDiFormatted = sdf.format(ngayDi);
        List<Student> ketQua = new ArrayList<>();
        for (Ticket ve : danhSachVe) {
            if (ve instanceof DailyTicket && ve.getDiemXuatPhat().equals(diemXuatPhat) && sdf.format(((DailyTicket) ve).getNgayDi()).equals(ngayDiFormatted)) {
                ketQua.add(ve.getSinhVien());
            }
        }
        return ketQua;
    }

    public List<Student> sapXepSinhVienTheoSoLuongVe() {
        Map<Student, Long> soLuongVeSinhVien = new HashMap<>();
        for (Student sinhVien : danhSachSinhVien) {
            long soLuongVe = danhSachVe.stream().filter(ve -> ve.getSinhVien().equals(sinhVien)).count();
            soLuongVeSinhVien.put(sinhVien, soLuongVe);
        }

        List<Student> sinhVienSapXep = new ArrayList<>(danhSachSinhVien);
        sinhVienSapXep.sort((s1, s2) -> {
            int soSanh = Long.compare(soLuongVeSinhVien.get(s2), soLuongVeSinhVien.get(s1));
            if (soSanh == 0) {
                return s1.getHoTen().compareTo(s2.getHoTen());
            }
            return soSanh;
        });
        return sinhVienSapXep;
    }
}

public class Main1 {
    public static void main(String[] args) throws Exception {
        OUBusSystem heThong = new OUBusSystem();
        
        // Thêm một số sinh viên
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Student sinhVien1 = new Student("001", "Nguyen Van A", sdf.parse("2000-01-01"), "Nam", "CNTT");
        Student sinhVien2 = new Student("002", "Le Thi B", sdf.parse("2000-02-02"), "Nu", "Dien");
        heThong.themSinhVien(sinhVien1);
        heThong.themSinhVien(sinhVien2);

        // Hiển thị thông tin các loại vé
        heThong.hienThiThongTinVe();

        // Mua một số vé
        Map<String, Object> annualParams = new HashMap<>();
        annualParams.put("diemXuatPhat", "Noi thanh");
        annualParams.put("namHieuLuc", 2024);
        annualParams.put("ngayMua", sdf.parse("2024-05-10"));
        heThong.muaVe(sinhVien1, "nam", annualParams);

        Map<String, Object> monthlyParams = new HashMap<>();
        monthlyParams.put("diemXuatPhat", "Noi thanh");
        monthlyParams.put("thangHieuLuc", 5);
        monthlyParams.put("namHieuLuc", 2024);
        monthlyParams.put("ngayMua", sdf.parse("2024-05-14"));
        heThong.muaVe(sinhVien2, "thang", monthlyParams);

        Map<String, Object> dailyParams = new HashMap<>();
        dailyParams.put("diemXuatPhat", "Noi thanh");
        dailyParams.put("ngayDi", sdf.parse("2024-05-20"));
        heThong.muaVe(sinhVien1, "ngay", dailyParams);

        // Kiểm tra vé
        Ticket ve = heThong.muaVe(sinhVien1, "ngay", dailyParams);
        System.out.println("Vé " + ve.getMaVe() + " hợp lệ: " + heThong.kiemTraVe(ve.getMaVe()));

        // Thống kê vé theo loại cho một sinh viên
        Map<String, Integer> thongKe = heThong.thongKeVeTheoLoai(sinhVien1);
        System.out.println("Sinh viên " + sinhVien1.getHoTen() + " đã mua " + thongKe.get("nam") + " vé năm, " + thongKe.get("thang") + " vé tháng, " + thongKe.get("ngay") + " vé ngày");

        // Tìm sinh viên theo điểm xuất phát và ngày
        List<Student> sinhViens = heThong.timSinhVienTheoDiemVaNgay("Noi thanh", sdf.parse("2024-05-20"));
        System.out.println("Sinh viên mua vé xuất phát từ Nội thành vào ngày 2024-05-20: " + sinhViens.stream().map(Student::getHoTen).toList());

        // Sắp xếp sinh viên theo số lượng vé đã mua
        List<Student> sinhVienSapXep = heThong.sapXepSinhVienTheoSoLuongVe();
        System.out.println("Sinh viên sắp xếp theo số lượng vé đã mua:");
        for (Student sv : sinhVienSapXep) {
            System.out.println(sv.getHoTen());
        }
    }
}

