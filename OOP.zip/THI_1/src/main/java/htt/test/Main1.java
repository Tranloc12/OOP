/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package htt.test;

/**
 *
 * @author admin
 */
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class Main1 {

    public static void main(String[] args) {
        try {
            QuanLyCongDan qlcd = new QuanLyCongDan();
            CongDan cd1 = new CongDan("287873", "Tran Quang Loc", "29/09/1222");
            CongDan cd2 = new CongDan("123456", "A", "21/01/2004");
            qlcd.themcd(cd1, cd2);
            CongDanNuocNgoai cdnn = new CongDanNuocNgoai("6666", "A", "21/01/2004", "18786");
            qlcd.themcd(cdnn);
            System.out.println("Danh sach cong dan nuoc ngoai");
            qlcd.xuatCd();
            for (CongDan cd : qlcd.timcdnn()) {
                System.out.println(cd.getHoTen());
            }
            Vacxin vacxin1 = new Vacxin("Covid-19", "USA");
            Vacxin vacxin2 = new Vacxin("Flu", "UK");
            TiemChung tiemChung1 = new TiemChung();
            TiemChung tiemChung2 = new TiemChung();
            tiemChung1.ghiNhanTiem(vacxin1, cd1, "Bệnh viện A");
            tiemChung2.ghiNhanTiem(vacxin2, cd1, "Bệnh viện B");
            System.out.println("Danh sách công dân đã tiêm ít nhất 2 mũi tiêm:");
            for (CongDan congDan : qlcd.tiem2muitrolen()) {
                System.out.println(congDan.getHoTen());
            }

        } catch (ParseException ex) {

        }

    }
}
