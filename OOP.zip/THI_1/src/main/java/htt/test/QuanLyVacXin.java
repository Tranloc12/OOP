/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package htt.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuanLyVacXin {

    /**
     * @return the ds
     */
    public List<Vacxin> getDs() {
        return ds;
    }

    /**
     * @param ds the ds to set
     */
    public void setDs(List<Vacxin> ds) {
        this.ds = ds;
    }
    private List<Vacxin> ds= new ArrayList<>();

    public QuanLyVacXin() {
    }
    
    public void themVacXin1(Vacxin... vx)
    {
        getDs().addAll(Arrays.asList(vx));
    }
    public void themVacXin(Vacxin... vx)
    {
        ds.addAll(Arrays.asList(vx));
    }
    public void sapXep()
    {
        this.getDs().sort(Comparator.comparing(Vacxin::getXuatXu).thenComparing(Vacxin::soLuong));
    }
}
