/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package htt.test;

import java.text.ParseException;
import java.util.Date;

/**
 *
 * @author admin
 */
public class CongDanNuocNgoai extends CongDan {
    
    private String soHoKhau;

    public CongDanNuocNgoai( String cccd, String hoTen, String ngaySinh, String soHoKhau) throws ParseException {
        super(cccd, hoTen, ngaySinh);
        this.soHoKhau = soHoKhau;
    }
    

    /**
     * @return the soHoKhau
     */
    public String getSoHoKhau() {
        return soHoKhau;
    }

    /**
     * @param soHoKhau the soHoKhau to set
     */
    public void setSoHoKhau(String soHoKhau) {
        this.soHoKhau = soHoKhau;
    }
    
    
    
}
