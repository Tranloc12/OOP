/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package htt.test;
import java.time.format.DateTimeFormatter;
import static htt.test.CauHinh.F;
import java.text.ParseException;
import java.time.LocalDate;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author admin
 */
public class CongDan {
    private String cccd;
    private String hoTen;
    private LocalDate ngaySinh;
    private List<TiemChung> tc=new  ArrayList<>();
    

    public CongDan(String cccd, String hoTen, LocalDate ngaySinh) {
        this.cccd = cccd;
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
       
    }

    public CongDan(String cccd, String hoTen, String ngaySinh) throws ParseException {
        this(cccd, hoTen, LocalDate.parse(ngaySinh, F));
    }

    @Override
    public String toString() {
        return "CongDan{" + "cccd=" + cccd + ", hoTen=" + hoTen + ", ngaySinh=" + ngaySinh + ", tc=" + tc + '}';
    }
    
 
    public boolean isTiem()
    {
        Date d = new Date();
        if(this.tc.isEmpty())
        
            return d.getYear()- this.ngaySinh.getYear()>=18;
        
        Calendar cl=this.tc.get(this.tc.size() -1 ).getNgayTiem();
        cl.add(Calendar.MONTH, 3);
        Calendar cld= new GregorianCalendar();
        return cld.compareTo(cl)>=0;
    }
    

    public String getCccd() {
        return cccd;
    }

    public String getHoTen() {
        return hoTen;
    }

    public LocalDate getNgaySinh() {
        return ngaySinh;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setNgaySinh(LocalDate ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    /**
     * @return the tc
     */
    public List<TiemChung> getTc() {
        return tc;
    }

    /**
     * @param tc the tc to set
     */
    public void setTc(List<TiemChung> tc) {
        this.tc = tc;
    }
    
    
}
