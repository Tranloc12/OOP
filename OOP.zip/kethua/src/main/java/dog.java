/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */

//extends là kế thừa từ A->B
public class dog extends animal{

    public dog() {
        
    }

    public void bark(){
        System.out.println("gau gau ");
    }
   
}
