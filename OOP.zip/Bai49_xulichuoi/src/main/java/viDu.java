
import java.awt.desktop.SystemEventListener;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class viDu {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("nhập chuỗi");
        String s = sc.nextLine();
        //hàm lấy độ dài chuôi => length();
        System.out.println(s.length());
        int doDai = s.length();
        //hàm lấy ra 1 kí tự tại vị trí => charAt(vị trí);
        for (int i = 0; i < doDai; i++) {
            System.out.println("vị trí" + i + "là: " + s.charAt(i));
        }
        //hàm  getChar(vị trí bắt đầu , vị trí kết thúc
        //mảng lưu dữ liệu , vị trí bắt đậu lưu của mảng)
        char[] arrayChar = new char[100];
        s.getChars(2, 4, arrayChar, 0);
        for (int i = 0; i < doDai; i++) {
            System.out.println("gia tri cua mang tai " + i + "là:" + arrayChar[i]);
        }
        //getByte => chuyển thành số 

        String s1 = "titv.vn";
        String s2 = "TITV.vn";
        String s3 = "titv.vn";
        //equals=>so sánh 2 chuỗi giống nhau , có phân biệt 
        System.out.println("s1 equals s2: " + s1.equals(s2));
        System.out.println("s1 equals s3: " + s1.equals(s3));
        //equalsIgnoreCase không phân biệt chữ hoa chữ thường 
        System.out.println("s1 ignoreCase s2" + s1.equalsIgnoreCase(s2));
        System.out.println("s1 ignoreCase s3" + s1.equalsIgnoreCase(s3));
        //hàm compareTo=> so sánh ><=
        String sv1 = "A";
        String sv2 = "B";
        String sv3 = "C";
        System.out.println("sv1 compareTo s2" + s1.compareTo(sv2));
        System.out.println("sv1 compareTo s3" + s1.compareTo(sv3));
        //hàm compareToIgnoreTo=> so sánh ><= không phân biệt hoa thường 
        //hàm regionMatches => so sánh một đoạn 
        String r1 = "titv.vn";
        String r2 = "tv.r";
        boolean check = r1.regionMatches(2, r2, 0, 4);
        System.out.println(check);
        //0937
        //0946
        //hàm starWith =>kiểm tra chuỗi bắt đàu bằng ....
        String sdt = "03789898900";
        System.out.println(sdt.startsWith("037"));
        System.out.println(sdt.startsWith("034"));
        //hàm endWith=> kiemr tra chuỗi kết thúc bằng .....
        /// kiểm tra cái tên file 
        String svc1 = "xin chao co chu, xin chao cac ban";
        String svc2 = "xin chao";
        String svc3 = "xin chao 123";
        char c1 = 'o';
        //hàm indexOf
        System.out.println("vi tri s2 trong s1 là" + s1.indexOf(s2));
        System.out.println("vi tri s3 trong s1 là" + s1.indexOf(s3));
        //sử dụng vị trí bắt đầu 
        System.out.println("vi tỉ cua s2 trong s1 là " + s1.indexOf(s2, 2));
        //tim kiem char 
        System.out.println("vi tỉ cua c1 trong s1 là " + s1.indexOf(c1, 2));
        //tim kiem sang ben phai sang trai =>lastIndexOf
        System.out.println("vi tri s2 trong s1 là" + s1.lastIndexOf(s2));
        //kiểm tra file đuôi .doc hoặc .pdf

        //hàm concat
        String b1 = "tIt  v     ";
        String b2 = ".vn";
        String b3 = b1 + b2;
        String b4 = b1.concat(b2);
        //hàm replace 
        String b5 = "tung.vn";
        System.err.println(b5.replaceAll("tung", "TITV"));
        // hàm toLowerCase
        //hàm toUpperCase 
        //hàm trim()=> xóa khoảng trắng dư thừa ở đầu chuôi 
        String k= "chung ta can pha lam gi";
         String sc2 = k.trim();
        System.out.println(sc2);
        //subString => cắt chuỗi vị trí đó trở về trước (giữ lại chuỗi ở sau)
        String v= "xin chào ca ban ";
        String v1= v.substring(2);
        String v2= v.substring(2 ,10 );
        System.out.println(v1);
        System.out.println(v2);
        
    }

}
