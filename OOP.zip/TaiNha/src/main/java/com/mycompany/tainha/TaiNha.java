/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tainha;

/**
 *
 * @author admin
 */
import java.util.Locale;
import java.util.Scanner;
public class TaiNha {

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.print("Vui long nhap chuoi de ban dau ");
        String ch= sc.nextLine();
        System.out.println("In chuoi vua moi nhap ra: "+ ch );
        for(int i=0;i<ch.length();i++)
        {
            char xh= ch.charAt(i);
            System.out.println("ki tu thu " +i +"="+  xh);
        }
        
            
    }
}
