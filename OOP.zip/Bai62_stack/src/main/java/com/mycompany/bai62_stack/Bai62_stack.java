/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai62_stack;

/**
 *
 * @author admin
 */
public class Bai62_stack {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
