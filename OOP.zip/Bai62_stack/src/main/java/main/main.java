/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<String> stackChuoi = new Stack<String>();
        //đưa giá trị vào 
//        stackChuoi.push("gia tri nào ");
//        //lấy giá trị ra ->xóa khỏi stack 
//        stackChuoi.pop();
//        //lấy giá trị ra ->không xóa khỏi stack 
//         stackChuoi.peek();
//        //rỗng hết 
//         stackChuoi.clear();
//
//        //xác định xem giá trị có tồn tại trong stack hay không 
//        stackChuoi.contains("giá trị ");
        //ví dụ đảo nguoc chuoix 
//        System.out.println("nhap chuoi: ");
//        String s = sc.nextLine();
//        //TITV
//        for (int i = 0; i < s.length(); i++) {
//            stackChuoi.push(s.charAt(i) + " ");
//
//        }
//        System.out.println("đao nguoc");
//        for (int i = 0; i < s.length(); i++) {
//            System.out.print(stackChuoi.pop());
//        }
        //chuyển hệ nhập phân sang hệ nhị phân 
        Stack<String> stackSoDu = new Stack<String>();
        System.out.println("nhap mot so nguyen duong ");
        int x = sc.nextInt();
        
        while (x > 0) {
            int soDu = x % 2;
            stackSoDu.push(soDu+"");
            x = x / 2;

        }
       
        System.out.println("so nhi phan ");
        int n= stackSoDu.size();
        for(int i=0;i<n;i++)
        {
            System.out.print(stackSoDu.pop());
        }

    }
}
