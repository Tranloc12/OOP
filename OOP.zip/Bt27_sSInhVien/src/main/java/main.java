/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        ngaySinh ngaySinh1 = new ngaySinh(26, 2, 2002);
        ngaySinh ngaySinh2 = new ngaySinh(21, 1, 2004);
        ngaySinh ngaySinh3 = new ngaySinh(17, 2, 2004);
        ngaySinh ngaySinh4 = new ngaySinh(26, 2, 2002);
        lop lop1 = new lop("lop A", "CNTT");
        lop lop2 = new lop("lop B", "CNSH");
        lop lop3 = new lop("lop C", "CNKT");
        lop lop4 = new lop("lop D", "CNDT");
        sinhVien sinhVien1 = new sinhVien("ma A", " minh ", ngaySinh1, 9.0, lop1);
        sinhVien sinhVien2 = new sinhVien("ma B", " van ", ngaySinh2, 8.0, lop2);
        sinhVien sinhVien3 = new sinhVien("ma C", " loc ", ngaySinh3, 9.9, lop3);
        sinhVien sinhVien4 = new sinhVien("ma D", " nam ", ngaySinh4, 4.9, lop4);
        System.out.println("ten khoa " + sinhVien1.tenKhoaSinhVienDangHoc());
        System.out.println("ten khoa " + sinhVien2.tenKhoaSinhVienDangHoc());
        System.out.println("ten khoa " + sinhVien3.tenKhoaSinhVienDangHoc());
        System.out.println("ten khoa " + sinhVien4.tenKhoaSinhVienDangHoc());
        System.out.println("sinh vien dau hay khong " + sinhVien1.hocSinhCoDauHayKhong());
        System.out.println("sinh vien dau hay khong " + sinhVien2.hocSinhCoDauHayKhong());
        System.out.println("sinh vien dau hay khong " + sinhVien3.hocSinhCoDauHayKhong());
        System.out.println("sinh vien dau hay khong " + sinhVien4.hocSinhCoDauHayKhong());
        System.out.println("sv1 va sv2"+sinhVien1.ngaySinhSinhVienGiongNhauKhong(sinhVien2));

    }
}
