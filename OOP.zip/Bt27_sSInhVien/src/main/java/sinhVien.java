/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class sinhVien {
    private String maSinhVien;
    private String hoVaTen;
    private ngaySinh ngayThangNam;
    private double diemTrungBinh;
    private lop lop;

    public sinhVien(String maSinhVien, String hoVaTen, ngaySinh ngayThangNam, double diemTrungBinh, lop lop) {
        this.maSinhVien = maSinhVien;
        this.hoVaTen = hoVaTen;
        this.ngayThangNam = ngayThangNam;
        this.diemTrungBinh = diemTrungBinh;
        this.lop = lop;
    }

    public String getMaSinhVien() {
        return maSinhVien;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public ngaySinh getNgayThangNam() {
        return ngayThangNam;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public lop getLop() {
        return lop;
    }

    public void setMaSinhVien(String maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public void setNgayThangNam(ngaySinh ngayThangNam) {
        this.ngayThangNam = ngayThangNam;
    }

    public void setDiemTrungBinh(double diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }

    public void setLop(lop lop) {
        this.lop = lop;
    }

   public String tenKhoaSinhVienDangHoc()
   {
       return this.lop.getTenKhoa(); 
   }
   public boolean hocSinhCoDauHayKhong()
   {
       if(this.getDiemTrungBinh()>=5)
       {
           return true ;
           
       }
       else 
           return false;
   }
   public boolean ngaySinhSinhVienGiongNhauKhong(sinhVien sinhVienKhac)
   {
       return this.ngayThangNam.equals(sinhVienKhac.ngayThangNam);
   }

}
