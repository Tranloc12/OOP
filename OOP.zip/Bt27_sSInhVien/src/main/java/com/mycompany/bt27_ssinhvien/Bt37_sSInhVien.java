/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bt27_ssinhvien;

/**
 *
 * @author admin
 */
public class Bt37_sSInhVien {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
