/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai66_generic;

/**
 *
 * @author admin
 */
public class Bai66_generic {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
