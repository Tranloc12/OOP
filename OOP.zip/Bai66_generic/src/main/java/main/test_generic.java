/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author admin
 */
public class test_generic {
    public static void main(String[] args) {
        box_generic b= new box_generic<Integer>(15);
        System.out.println("Gia Tri: "+ b.getValue());
        box_generic b1= new box_generic<String>("banh beo");
        System.out.println("Gia Tri: "+b.getValue());
    }
}
