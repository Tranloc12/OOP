/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author admin
 */
public class test {
    public static void main(String[] args) {
       box b= new box(15);
        System.out.println("Gia tri: "+b.getValue());
        //box b= new box(15.5)-lỗi 
        //sang chuỗi - cũng lỗi 
        
    }
}
