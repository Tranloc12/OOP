/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author admin
 */
public class SinhVienTest {
    
    public SinhVienTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getMaSinhVien method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testGetMaSinhVien() {
        System.out.println("getMaSinhVien");
        SinhVien instance = null;
        int expResult = 0;
        int result = instance.getMaSinhVien();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHoVaTen method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testGetHoVaTen() {
        System.out.println("getHoVaTen");
        SinhVien instance = null;
        String expResult = "";
        String result = instance.getHoVaTen();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTenLop method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testGetTenLop() {
        System.out.println("getTenLop");
        SinhVien instance = null;
        String expResult = "";
        String result = instance.getTenLop();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDiemTrungBinh method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testGetDiemTrungBinh() {
        System.out.println("getDiemTrungBinh");
        SinhVien instance = null;
        double expResult = 0.0;
        double result = instance.getDiemTrungBinh();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMaSinhVien method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testSetMaSinhVien() {
        System.out.println("setMaSinhVien");
        int maSinhVien = 0;
        SinhVien instance = null;
        instance.setMaSinhVien(maSinhVien);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHoVaTen method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testSetHoVaTen() {
        System.out.println("setHoVaTen");
        String hoVaTen = "";
        SinhVien instance = null;
        instance.setHoVaTen(hoVaTen);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTenLop method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testSetTenLop() {
        System.out.println("setTenLop");
        String tenLop = "";
        SinhVien instance = null;
        instance.setTenLop(tenLop);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDiemTrungBinh method, of class SinhVien.
     */
    @org.junit.jupiter.api.Test
    public void testSetDiemTrungBinh() {
        System.out.println("setDiemTrungBinh");
        double diemTrungBinh = 0.0;
        SinhVien instance = null;
        instance.setDiemTrungBinh(diemTrungBinh);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
