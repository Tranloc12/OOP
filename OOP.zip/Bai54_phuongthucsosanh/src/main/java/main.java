/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        SinhVien sv1 = new SinhVien(100, " Trần Quang Lộc", "Lop 1", 9);
        SinhVien sv2 = new SinhVien(150, " Nguyễn Hữu tuấn ", "Lop 2", 8);
        SinhVien sv3 = new SinhVien(120, " Hà Thanh Tiến ", "Lop 3", 7);
        System.out.println(sv1.compareTo(sv2));
        System.out.println(sv3.compareTo(sv2));
        System.out.println(sv1.compareTo(sv2));

    }
}
