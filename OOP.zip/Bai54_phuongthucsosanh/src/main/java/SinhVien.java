/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class SinhVien implements Comparable<SinhVien> {

    private int maSinhVien;
    private String hoVaTen;
    private String tenLop;
    private double diemTrungBinh;

    public SinhVien(int maSinhVien, String hoVaTen, String tenLop, double diemTrungBinh) {
        this.maSinhVien = maSinhVien;
        this.hoVaTen = hoVaTen;
        this.tenLop = tenLop;
        this.diemTrungBinh = diemTrungBinh;
    }

    public int getMaSinhVien() {
        return maSinhVien;
    }

    public String getHoVaTen() {
        return hoVaTen;
    }

    public String getTenLop() {
        return tenLop;
    }

    public double getDiemTrungBinh() {
        return diemTrungBinh;
    }

    public void setMaSinhVien(int maSinhVien) {
        this.maSinhVien = maSinhVien;
    }

    public void setHoVaTen(String hoVaTen) {
        this.hoVaTen = hoVaTen;
    }

    public void setTenLop(String tenLop) {
        this.tenLop = tenLop;
    }

    public void setDiemTrungBinh(double diemTrungBinh) {
        this.diemTrungBinh = diemTrungBinh;
    }

    public String getTen() {
        String s= this.hoVaTen.trim();
        s = s.trim();
        if (s.indexOf(" ") >= 0) {
            int vt = s.lastIndexOf(" ");
            return s.substring(vt + 1);

        } else {
            return s;
    
        }
    }

    @Override
    public int compareTo(SinhVien o) {
        //<0;
        //=0;
        //>0;
        //dua tren so sanh ten
        //ten: adam. obama
        String tenThis = this.getTen();
        String tenO = o.getTen();
        return this.maSinhVien - o.maSinhVien;
    }

}
