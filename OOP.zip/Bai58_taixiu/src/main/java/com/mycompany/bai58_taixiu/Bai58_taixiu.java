/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai58_taixiu;

/**
 *
 * @author admin
 */
public class Bai58_taixiu {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
