/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taixiu;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author admin
 */
// 1 tài khoản 
//   + người chơi có quyền đặt cược số tiền < || = tiền họ có 
//   + luật chơi :
//        -có 3 viên xúc xắc , mỗi viên xúc có 6 mặt có giá tri từ 1->6
//        - kết qả= x1+x2+x3
//             + nêu tổng = 3 hoặc 18 thì cái ăn 
//                + nếu tổng =4- 10 xỉu thì người đặt xỉu ăn còn lại thua 
//                + nếu tổng= 11-17 tài thì ngượi đặt tài ăn còn lại thau 
public class taixiu {

    public static void main(String[] args) {

        double taiKhoanNguoiChoi = 5000;
        Scanner sc = new Scanner(System.in);
        int chon;

        do {
            System.out.println("----------MENU------------");
            System.out.println("1. de tiep tuc choi ");
            System.out.println("chon phim bat ki thoat");
            System.out.println("vui long chon so ban muon ");
            chon = sc.nextInt();

            if (chon == 1) {
                System.out.println("***Tro Choi Bat Dau***");
                System.out.println("tai khoan cua ban: " + taiKhoanNguoiChoi + " so tien ban muon cuoc: ");
                double soTienCuoc = 0;

                // đặt cược
                do {
                    System.out.println("***Dat Cuoc tu 0 đến <=" + taiKhoanNguoiChoi + " : ");
                    soTienCuoc = sc.nextDouble();
                } while (soTienCuoc <= 0 || soTienCuoc > taiKhoanNguoiChoi);

                // chọn tài xỉu
                int luaChonTaiXiu = 0;
                do {
                    System.out.println("***** chon: 1 <-> Tai || 2 <-> Xiu ");
                    luaChonTaiXiu = sc.nextInt();
                } while (luaChonTaiXiu != 1 && luaChonTaiXiu != 2);

                // tung xúc sắc
                Random xucXich = new Random();
                int ketQua = xucXich.nextInt(6) + 1;
                int ketQua1 = xucXich.nextInt(6) + 1;
                int ketQua2 = xucXich.nextInt(6) + 1;
                int tong = ketQua + ketQua1 + ketQua2;

                // tính toán 
                System.out.println("ket qua: " + ketQua + "-" + ketQua1 + "-" + ketQua2);

                if (tong == 3 || tong == 18) {
                    taiKhoanNguoiChoi -= soTienCuoc;
                    System.out.println("tong la: " + tong + "nha cai an het ban thua ");
                    System.out.println("tai khoan cua ban " + taiKhoanNguoiChoi);
                } else if (tong >= 4 && tong <= 10) {
                    System.out.println("tong la: " + tong + "=> xỉu");
                    if (luaChonTaiXiu == 2) {
                        System.out.println("ban thang");
                        taiKhoanNguoiChoi += soTienCuoc;
                        System.out.println("tai khoan cua ban " + taiKhoanNguoiChoi);
                    } else {
                        System.out.println("ban thua");
                        taiKhoanNguoiChoi -= soTienCuoc;
                        System.out.println("tai khoan cua ban " + taiKhoanNguoiChoi);
                    }
                } else {
                    System.out.println("tong la: " + tong + "=> tai");
                    if (luaChonTaiXiu == 1) {
                        System.out.println("ban thang");
                        taiKhoanNguoiChoi += soTienCuoc;
                        System.out.println("tai khoan cua ban " + taiKhoanNguoiChoi);
                    } else {
                        System.out.println("ban thua");
                        taiKhoanNguoiChoi -= soTienCuoc;
                        System.out.println("tai khoan cua ban " + taiKhoanNguoiChoi);
                    }
                }
            }
        } while (chon != 0);

        sc.close();
    }
}


