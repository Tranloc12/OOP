/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author admin
 */
public class main {

    Set<String> thungPhieuDuThuong = new HashSet<String>();

    public main() {
    }

    public boolean themPhieu(String giaTri) {
        return this.thungPhieuDuThuong.add(giaTri);
    }

    public boolean xoaPhieu(String giaTri) {
        return this.thungPhieuDuThuong.remove(giaTri);
    }

    public boolean kiemTraPhieuTonTai(String giaTri) {
        return this.thungPhieuDuThuong.contains(giaTri);

    }

    public void xoaAll() {
        this.thungPhieuDuThuong.clear();
    }

    public int laySoLuong() {
        return this.thungPhieuDuThuong.size();
    }

    public String rutMotPhieu() {
        String ketQua = "";
        Random rd = new Random();
        int viTri = rd.nextInt(this.thungPhieuDuThuong.size());
        ketQua = (String) this.thungPhieuDuThuong.toArray()[viTri];
        return ketQua;
    }

    public void inTatca() {
        System.out.println(Arrays.toString(this.thungPhieuDuThuong.toArray()));
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        main rt = new main();

        int chon = 0;

        do {
            System.out.println("_______________________________");
            System.out.println("____________MENU_______________");
            System.out.println("1.them ma so du thuong: ");
            System.out.println("2.xoa ma so du thuong");
            System.err.println("3.kiem tra ma so du thuong co ton tai hay khong ");
            System.out.println("4.xoa all cac phieu du thuong");
            System.out.println("5.so luong phieu du thuong");
            System.out.println("6.rut tham trung thuong");
            System.out.println("7.in tat ca phieu");
            System.out.println("0.thoat");
            System.out.println("Nhap So Ban Muon");
            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {

                case 1:
                    System.out.println("nhap ma du thuong: ");
                    String giaTri = sc.nextLine();

                    rt.themPhieu(giaTri);
                    break;
                case 2:
                    System.out.println("nhap ma du thuong: ");
                    String giaTri1 = sc.nextLine();
                    rt.xoaPhieu(giaTri1);
                    break;
                case 3:
                     System.out.println("nhap ma du thuong: ");
                    String  giaTri2 = sc.nextLine();
                    System.out.println("ket qa kiem tra: " + rt.kiemTraPhieuTonTai(giaTri2));
                    break;
                case 4:
                    rt.xoaAll();
                    break;
                case 5:
                    System.out.println("soluong phieu la: " + rt.laySoLuong());
                    break;
                case 6:
                    System.out.println("ma so trung thuong la: " + rt.rutMotPhieu());
                    break;
                case 7:
                    System.out.println("in cac ma phieu du thuong la ");
                    rt.inTatca();
                    break;
                default:
                    throw new AssertionError();
            }

        } while (chon != 0);

    }
}
