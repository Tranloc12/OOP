/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai64_collections;

/**
 *
 * @author admin
 */
public class Bai64_Collections {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
