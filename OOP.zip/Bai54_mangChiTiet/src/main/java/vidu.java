
import java.util.Arrays;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class vidu {

    public static void main(String[] args) {
        //kiểu nguyên thủy 
        int[] arr = {1, 2, 3, 4};

        //copy mang
        int[] arr1 = arr;
        arr1[0] = 100;
        System.out.println("mang1 " + Arrays.toString(arr1));
        //copy mang
        int[] arr2 = arr.clone();
        arr2[0] = 50;
        System.out.println("mang2 " + Arrays.toString(arr2));
        //copy mang 
        int[] arr3 = new int[arr.length];
        System.arraycopy(arr, 0, arr3, 0, arr.length);
        arr3[0] = 90;
        System.out.println("mang2 " + Arrays.toString(arr3));
        //kiểu nguyên thủy
        String[] arr4= {"titv",".vn"};

    }
}
