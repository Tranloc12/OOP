/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class TacGia {
    private String tacgia;
    private Ngay ngaysinh;

    public TacGia(String tacgia, Ngay ngaysinh) {
        this.tacgia = tacgia;
        this.ngaysinh = ngaysinh;
    }

    public String getTacgia() {
        return tacgia;
    }

    public Ngay getNgaysinh() {
        return ngaysinh;
    }

    public void setTacgia(String tacgia) {
        this.tacgia = tacgia;
    }

    public void setNgaysinh(Ngay ngaysinh) {
        this.ngaysinh = ngaysinh;
    }
    
}
