/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {
    public static void main(String[] args) {
        Ngay ngay1= new Ngay(15,5,2018);
        Ngay ngay2= new Ngay(15,5,2018);
        Ngay ngay3= new Ngay(15,5,2018);
        TacGia tacGia1= new TacGia("tung ",ngay1);
         TacGia tacGia2= new TacGia("tung le",ngay2);
          TacGia tacGia3= new TacGia("tung le van",ngay3);
          Sach sach1= new Sach("lap trinh c",500,2003,tacGia1);
          
    }
}
