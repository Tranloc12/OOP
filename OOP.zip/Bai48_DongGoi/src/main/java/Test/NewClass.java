/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import code.test;

/**
 *
 * @author admin
 */
public class NewClass {
    public static void main(String[] args) {
        test t = new test(5,6);
        System.out.println("xuat ra "+t.getA());
    }
}
