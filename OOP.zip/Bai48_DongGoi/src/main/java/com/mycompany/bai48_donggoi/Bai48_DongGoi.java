/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai48_donggoi;

/**
 *
 * @author admin
 */
public class Bai48_DongGoi {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
