/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.doanthang;

/**
 *
 * @author admin
 */
public class DoanThang {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
