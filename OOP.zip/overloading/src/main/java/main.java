/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {
    public static void main(String[] args) {
        MyMath mm= new MyMath();
        System.out.println(mm.timMin(5,5));
          System.out.println(mm.timMin(5.8,6.0));
          System.out.println(mm.tinhTong(5.0, 6.0));
          double arr[]= new double[]{1,2,3,5,8,9};
          System.out.println(mm.tinhTong(arr));
    }
}
