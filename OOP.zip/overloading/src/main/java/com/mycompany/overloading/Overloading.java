/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.overloading;

/**
 *
 * @author admin
 */
public class Overloading {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
