/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class MyMath {
    //ví dụ về overloading - cùng 1 phương thức nhưng chỉ khác kiểu dữ liệu 
    public int timMin(int a, int b)
    {
        if(a<b)
        {
            return a;
            
        }
        else return b;
    }
    
    public double timMin(double a, double b)
    {
         if(a<b)
        {
            return a;
            
        }
        else return b;
        
    }
    public double tinhTong( double a, double b)
    {
        return a+b;
        
    }
    public double tinhTong(double[] arr)
    {
        double tinhtong=0;
        for(int i=0;i<arr.length;i++)
        {
            tinhtong+= arr[i];
        }
        return tinhtong;
    }
}
