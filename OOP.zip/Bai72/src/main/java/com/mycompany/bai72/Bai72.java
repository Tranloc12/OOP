/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai72;

import java.io.BufferedReader;
import java.io.File;
import java.nio.file.Files;

/**
 *
 * @author admin
 */
public class Bai72 {

    public static void main(String[] args) {
        File f= new File("C:\Users\admin\Documents\NetBeansProjects\Bai72\src\main\java");
       try {
             BufferedReader bfd= Files.newBufferedReader();

        } catch (Exception e) {
        }
    }
}
