/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author admin
 */
public class Bai63_Queue
{

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
