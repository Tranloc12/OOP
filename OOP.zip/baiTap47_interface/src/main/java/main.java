/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        System.out.println("TEST A:");
        MayTinhCasioFX500 mfx500 = new MayTinhCasioFX500();
        MayTinhVinacal500 mvn500 = new MayTinhVinacal500();
        System.out.println("5+3=" + mfx500.cong(5, 3));
        System.out.println("5-3=" + mfx500.tru(5, 3));
        System.out.println("5*3=" + mfx500.nhan(5, 3));
        System.out.println("5/3=" + mfx500.chia(5, 3));
        double[] arr = new double[]{5, 2, 5, 3, 9, 8, 5, 7, 9, 1};
        double[] arr1 = new double[]{5, 2, 5, 3, 9, 8, 5, 7, 9, 1};
        SapXepChen sxchen = new SapXepChen();
        SapXepChon sxChon = new SapXepChon();
        sxchen.sapXepTangDan(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.println( arr[i]);
        }
        
        sxchen.sapXepTangDan(arr);
        for (int i = 0; i < arr1.length; i++) {
            System.out.println( arr1[i]);
        }
         System.out.println("Test cau c");
         PhanMemMayTinh pmmt= new PhanMemMayTinh();
         System.out.println("3+5" + pmmt.cong(3, 5));
         double[] arr3= new double[]{6,8,5,7,2,5,6};
         sxchen.sapXepTangDan(arr);
         for(int i=0;i<arr.length;i++)
         {
             System.out.println(arr[i]);
         }
        

    }
}
