/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author admin
 */
public interface MayTinhBoTui {

    public abstract double cong(double a, double b);

    public double tru(double a, double b);

    public double nhan(double a, double b);

    public double chia(double a, double b);

}
