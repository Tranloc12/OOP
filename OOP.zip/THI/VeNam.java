/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class VeNam extends VeXe{
    private LocalDate namHieuLuc;
    private double gia;

    public VeNam( String sinhVienMuaVe, String diaDiem) {
        super(sinhVienMuaVe, diaDiem);
//        this.namHieuLuc = namHieuLuc;
//        this.gia = gia;
    }

    @Override
    public void hienThi() {
        super.hienThi(); 
        System.out.printf("\nNamHieuLuc:%s\nGia:%.1f", tinhNam().format(CauHinh.FORMATTER),tinhGia());
    }
    public double tinhGia() {
        if(LocalDate.now().getMonthValue() < 6)
            return 4500000;
        else
            return 3000000;
    }
    public LocalDate tinhNam() {
        return LocalDate.now().plusYears(1);
    }
    /**
     * @return the namHieuLuc
     */
    public LocalDate getNamHieuLuc() {
        return namHieuLuc;
    }

    /**
     * @param namHieuLuc the namHieuLuc to set
     */
    public void setNamHieuLuc(LocalDate namHieuLuc) {
        this.namHieuLuc = namHieuLuc;
    }

    /**
     * @return the gia
     */
    public double getGia() {
        return gia;
    }

    /**
     * @param gia the gia to set
     */
    public void setGia(double gia) {
        this.gia = gia;
    }
}
