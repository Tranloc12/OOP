/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class VeThang extends VeXe{
    private LocalDate thangNam;
    private double giaVe;

    public VeThang(String sinhVienMuaVe, String diaDiem) {
        super(sinhVienMuaVe, diaDiem);
//        this.giaVe = giaVe;
    }
    public double tinhGiaVe() {
        if(LocalDate.now().getDayOfMonth() < 15)
            return 450000;
        else
            return 300000;
        
    }   
    public LocalDate tinhHieuLuc() {
        return LocalDate.now().plusMonths(1);
    }
    @Override
    public void hienThi() {
        super.hienThi(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
        System.out.printf("\nThoi gian hieu luc:%s\nGia:%.1f", tinhHieuLuc().format(CauHinh.FORMATTER), tinhGiaVe());
    }
    
    /**
     * @return the thangNam
     */
    public LocalDate getThangNam() {
        return thangNam;
    }

    /**
     * @param thangNam the thangNam to set
     */
    public void setThangNam(LocalDate thangNam) {
        this.thangNam = thangNam;
    }

    /**
     * @return the giaVe
     */
    public double getGiaVe() {
        return giaVe;
    }

    /**
     * @param giaVe the giaVe to set
     */
    public void setGiaVe(double giaVe) {
        this.giaVe = giaVe;
    }
    
}
