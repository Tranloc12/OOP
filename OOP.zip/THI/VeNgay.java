/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

import java.time.LocalDate;

/**
 *
 * @author admin
 */
public class VeNgay extends VeXe{
    private LocalDate ngayDi;
    private double gia = 20000;

    public VeNgay(String sinhVienMuaVe, String diaDiem) {
        super(sinhVienMuaVe, diaDiem);
//        this.ngayDi = ngayDi;
//        this.gia = gia;
    }

    public LocalDate ngayDi() {
        return LocalDate.now().plusDays(1);
    }
    
    @Override
    public void hienThi() {
        super.hienThi(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
        System.out.printf("\nNamHieuLuc:%s\nGia:%.1f", ngayDi().format(CauHinh.FORMATTER),this.gia);
    }

    /**
     * @return the ngayDi
     */
    public LocalDate getNgayDi() {
        return ngayDi;
    }

    /**
     * @param ngayDi the ngayDi to set
     */
    public void setNgayDi(LocalDate ngayDi) {
        this.ngayDi = ngayDi;
    }

    /**
     * @return the gia
     */
    public double getGia() {
        return gia;
    }

    /**
     * @param gia the gia to set
     */
    public void setGia(double gia) {
        this.gia = gia;
    }
}
