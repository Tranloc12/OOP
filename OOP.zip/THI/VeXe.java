/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

/**
 *
 * @author admin
 */
public class VeXe {
    private static int dem1;
    private String maVe;
    private String sinhVienMuaVe;
    String diaDiem;
    {
        setMaVe(String.format("%03d", ++dem1));
    }

    public VeXe(String sinhVienMuaVe, String diaDiem) {
        this.sinhVienMuaVe = sinhVienMuaVe;
        this.diaDiem = diaDiem;
    }
    
    public void hienThi() {
        System.out.printf("\nMaVe:%s\nSVmuaVe:%s\nDiaDiem:%s", maVe,sinhVienMuaVe,diaDiem);
    }
    /**
     * @return the maVe
     */
    public String getMaVe() {
        return maVe;
    }

    /**
     * @param maVe the maVe to set
     */
    public void setMaVe(String maVe) {
        this.maVe = maVe;
    }

    /**
     * @return the sinhVienMuaVe
     */
    public String getSinhVienMuaVe() {
        return sinhVienMuaVe;
    }

    /**
     * @param sinhVienMuaVe the sinhVienMuaVe to set
     */
    public void setSinhVienMuaVe(String sinhVienMuaVe) {
        this.sinhVienMuaVe = sinhVienMuaVe;
    }

    /**
     * @return the diaDiem
     */
    public String getDiaDiem() {
        return diaDiem;
    }

    /**
     * @param diaDiem the diaDiem to set
     */
    public void setDiaDiem(String diaDiem) {
        this.diaDiem = diaDiem;
    }
    
}
