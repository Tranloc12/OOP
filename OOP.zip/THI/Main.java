/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.nhtg.exam02;

/**
 *
 * @author admin
 */
public class Main {

    public static void main(String[] args) {
        //a)HienThiDSCacLoai
        SinhVien s1 = new SinhVien("Giang","Nam");
        s1.hienThi();
        System.out.println();
        VeXe v1 = new VeNam("Giang","Khu Du Lich Van Thanh");
        VeXe v2 = new VeThang("Giang","Khu Du Lich Van Thanh");
        VeXe v3 = new VeNgay("Giang","Khu Du Lich Van Thanh");
        s1.themVe(v3);
        QuanLyVe ql1 = new QuanLyVe();
        ql1.themVe(v1,v2,v3);
//        ql1.muaVe(002);

        ql1.hienThi();
        
    }
}
