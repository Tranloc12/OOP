/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author admin
 */
public class SinhVien {
    private static int dem;
    private int id = ++dem;
    private String hoTen;
    private LocalDate ngaySinh = LocalDate.now();
    private String gioiTinh;
    private List<VeXe> dsVe = new ArrayList<> ();
    

    public SinhVien(String hoTen, String gioiTinh) {
        this.hoTen = hoTen;
        this.gioiTinh = gioiTinh;
    }
    public void hienThi() {
        System.out.printf("MaSv:%d\nHoTen:%s\nNgaySinh:%s\nGioiTinh:%s", id, hoTen,ngaySinh.format(CauHinh.FORMATTER),gioiTinh);
    }
    public void themVe(VeXe vx) {
        this.dsVe.addAll(Arrays.asList(vx));
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the hoTen
     */
    public String getHoTen() {
        return hoTen;
    }

    /**
     * @param hoTen the hoTen to set
     */
    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    /**
     * @return the ngaySinh
     */
    

    /**
     * @return the gioiTinh
     */
    public String getGioiTinh() {
        return gioiTinh;
    }

    /**
     * @param gioiTinh the gioiTinh to set
     */
    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    /**
     * @return the ngaySinh
     */
    public LocalDate getNgaySinh() {
        return ngaySinh;
    }

    /**
     * @param ngaySinh the ngaySinh to set
     */
    public void setNgaySinh(LocalDate ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    /**
     * @return the dsVe
     */
    public List<VeXe> getDsVe() {
        return dsVe;
    }

    /**
     * @param dsVe the dsVe to set
     */
    public void setDsVe(List<VeXe> dsVe) {
        this.dsVe = dsVe;
    }
    
}
