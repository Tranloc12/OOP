/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nhtg.exam02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuanLyVe {
    private List<VeXe> dssv = new ArrayList<> ();
    public void hienThi() {
        this.dssv.forEach(s -> s.hienThi());
    }
    public void themVe(VeXe... a) {
        this.dssv.addAll(Arrays.asList(a));
    }
    public VeXe muaVe(String maVe) {
       return this.dssv.stream().filter(s -> s.getMaVe().equals(maVe)).findFirst().get();
    }
    public long tinhSoVe() {
        return this.dssv.stream().count();
    }
//    public void soatVe() {
//        
//    }
    /**
     * @return the dssv
     */
    public List<VeXe> getDssv() {
        return dssv;
    }

    /**
     * @param dssv the dssv to set
     */
    public void setDssv(List<VeXe> dssv) {
        this.dssv = dssv;
    }
    
}
