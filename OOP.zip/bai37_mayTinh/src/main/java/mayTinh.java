/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class mayTinh {

    private hangSanXuat hangSanXuat;
    private ngay ngaySanXuat;
    private double giaBan;
    private double thoiGianBaoHanh;

    public mayTinh(hangSanXuat hangSanXuat, ngay ngaySanXuat, double giaBan, double thoiGianBaoHanh) {
        this.hangSanXuat = hangSanXuat;
        this.ngaySanXuat = ngaySanXuat;
        this.giaBan = giaBan;
        this.thoiGianBaoHanh = thoiGianBaoHanh;
    }

    public hangSanXuat getHangSanXuat() {
        return hangSanXuat;
    }

    public ngay getNgaySanXuat() {
        return ngaySanXuat;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public double getThoiGianBaoHanh() {
        return thoiGianBaoHanh;
    }

    public void setHangSanXuat(hangSanXuat hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public void setNgaySanXuat(ngay ngaySanXuat) {
        this.ngaySanXuat = ngaySanXuat;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public void setThoiGianBaoHanh(double thoiGianBaoHanh) {
        this.thoiGianBaoHanh = thoiGianBaoHanh;
    }

    public boolean kiemTraGiaMayTinh(mayTinh mayTinhKhac) {
        return this.giaBan < mayTinhKhac.giaBan;
    }

    @Override
    public String toString() {
        return "mayTinh{" + "hangSanXuat=" + hangSanXuat + ", ngaySanXuat=" + ngaySanXuat + ", giaBan=" + giaBan + ", thoiGianBaoHanh=" + thoiGianBaoHanh + '}';
    }

    

    

   
}
