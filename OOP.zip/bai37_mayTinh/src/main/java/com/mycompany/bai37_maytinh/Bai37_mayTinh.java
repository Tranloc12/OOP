/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai37_maytinh;

/**
 *
 * @author admin
 */
public class Bai37_mayTinh {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
