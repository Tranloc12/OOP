/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class hangSanXuat {
    private String tenHang;
    private quocGia quocGia;

    public hangSanXuat(String tenHang, quocGia quocGia) {
        this.tenHang = tenHang;
        this.quocGia = quocGia;
    }

    public String getTenHang() {
        return tenHang;
    }

    public quocGia getQuocGia() {
        return quocGia;
    }

    public void setTenHang(String tenHang) {
        this.tenHang = tenHang;
    }

    public void setQuocGia(quocGia quocGia) {
        this.quocGia = quocGia;
    }

    String getTenQuocGia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String layTenQuocGia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
