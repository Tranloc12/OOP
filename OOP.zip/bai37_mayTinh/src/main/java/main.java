/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        ngay Ngay1 = new ngay(10, 4, 2024);
        ngay Ngay2 = new ngay(20, 4, 2024);
        ngay Ngay3 = new ngay(30, 4, 2024);
        quocGia qG1 = new quocGia("VN", "VietNam");
        quocGia qG2 = new quocGia("HQ", "Hàn Quốc");
        quocGia qG3 = new quocGia("NB", "Nhật Bản");
        hangSanXuat hSX1 = new hangSanXuat("DELL", qG1);
        hangSanXuat hSX2 = new hangSanXuat("ASUS", qG2);
        hangSanXuat hSX3 = new hangSanXuat("MAC", qG3);
        mayTinh mT1 = new mayTinh(hSX1, Ngay1, 18.000, 3);
        mayTinh mT2 = new mayTinh(hSX2, Ngay2, 28.000, 3);
        mayTinh mT3 = new mayTinh(hSX3, Ngay3, 38.000, 3);
        System.out.println(mT1.toString());
        System.out.println("so sanh may1 be may2"+ mT1.kiemTraGiaMayTinh(mT2));

    }
}
