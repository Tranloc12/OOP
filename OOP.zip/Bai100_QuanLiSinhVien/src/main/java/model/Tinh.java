/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 *
 * @author admin
 */
public class Tinh {
    private int maTInh;
    private String tenTinh;

    public Tinh(int maTInh, String tenTinh) {
        this.maTInh = maTInh;
        this.tenTinh = tenTinh;
    }

    public int getMaTInh() {
        return maTInh;
    }

    public String getTenTinh() {
        return tenTinh;
    }

    public void setMaTInh(int maTInh) {
        this.maTInh = maTInh;
    }

    public void setTenTinh(String tenTinh) {
        this.tenTinh = tenTinh;
    }

    @Override
    public String toString() {
        return "Tinh{" + "maTInh=" + maTInh + ", tenTinh=" + tenTinh + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + this.maTInh;
        hash = 59 * hash + Objects.hashCode(this.tenTinh);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tinh other = (Tinh) obj;
        if (this.maTInh != other.maTInh) {
            return false;
        }
        return Objects.equals(this.tenTinh, other.tenTinh);
    }
    
}
