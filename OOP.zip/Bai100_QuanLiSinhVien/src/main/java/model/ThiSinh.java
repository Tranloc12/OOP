/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author admin
 */
public class ThiSinh {

    private int maThiSinh;
    private String tenThiSinh;
    private Tinh queQuan;
    private String ngaySinh;
    private String gioiTinh;
    private float diemMon1;
    private float diemMon2;
    private float diemMon3;

    public ThiSinh() {
    }

    public ThiSinh(int maThiSinh, String tenThiSinh, Tinh queQuan, String ngaySinh, String gioiTinh, float diemMon1, float diemMon2, float diemMon3) {
        this.maThiSinh = maThiSinh;
        this.tenThiSinh = tenThiSinh;
        this.queQuan = queQuan;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.diemMon1 = diemMon1;
        this.diemMon2 = diemMon2;
        this.diemMon3 = diemMon3;
    }
    

}
