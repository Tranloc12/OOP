/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class QLDS {

    private ArrayList<ThiSinh> dsThiSinh;

    public QLDS() {
        this.dsThiSinh = new ArrayList<ThiSinh>();
    }

    public QLDS(ArrayList<ThiSinh> dsThiSinh) {
        this.dsThiSinh = dsThiSinh;
    }

    public ArrayList<ThiSinh> getDsThiSinh() {
        return dsThiSinh;
    }

    public void setDsThiSinh(ArrayList<ThiSinh> dsThiSinh) {
        this.dsThiSinh = dsThiSinh;
    }

    public void insert(ThiSinh sinhVienMoi) {
        this.dsThiSinh.add(sinhVienMoi);
    }

    public void move(ThiSinh sinhvien) {
        this.dsThiSinh.remove(sinhvien);
    }

    public void upDate(ThiSinh sinhvien) {
        this.dsThiSinh.remove(sinhvien);
        this.dsThiSinh.add(sinhvien);
    }
}
