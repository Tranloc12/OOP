/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import java.util.ArrayList;
import model.QLDS;
import model.ThiSinh;
import model.Tinh;

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        Tinh t = new Tinh(77, "Binh Dinh");
        Tinh t1 = new Tinh(59, "TPHCM");
        ThiSinh ts = new ThiSinh(100, "A", t, "25/2/2004", "Nam", 8, 9, 10);
        ThiSinh ts1 = new ThiSinh(100, "A", t, "25/2/2004", "Nam", 8, 9, 10);
        ArrayList<ThiSinh> qlds= new ArrayList<>();
        
        
    }
}
