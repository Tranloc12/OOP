/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javatainha;

/**
 *
 * @author admin
 */
public class JAVATAINHA {
    public static void main(String[] args) {
          
    }
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
