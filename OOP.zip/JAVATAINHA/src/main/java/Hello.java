/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Hello {

    public static void main(String[] args) {
        int[] a = {4, 5, 6, 8, 3};
        System.out.println("Chiều dài: " + a.length);

    }

}
