/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class DoanThang {

    private Diem diem1;
    private Diem diem2;

    public DoanThang(Diem diem1, Diem diem2) {
        this.diem1 = diem1;
        this.diem2 = diem2;
    }
/**
     * @return  the tam
     */
    public Diem getDiem1() {
        return diem1;
    }

    public Diem getDiem2() {
        return diem2;
    }

    public void setDiem1(Diem diem1) {
        this.diem1 = diem1;
    }

    public void setDiem2(Diem diem2) {
        this.diem2 = diem2;
    }

    public void doanThang() {
        System.out.println("xuat ra Doan Thang X[(" + diem1.getHoanhDo() + "," + diem1.getTungDo() + ")" + ";(" + diem2.getHoanhDo() + "," + diem2.getTungDo() + ")]");
    }

    public void doDaiDoanThang() {
        System.out.println("do dai doan thang: " + diem1.khoangCach(diem2));
    }

    public void trungDiem() {
        System.out.println("trung diem: " + (diem1.getHoanhDo() + diem2.getHoanhDo()) / 2 + "," + (diem1.getTungDo() + diem2.getTungDo()) / 2);
    }

    public boolean kiemTraSS(Diem diemKhac1, Diem diemKhac2) {
        double x = diem1.getHoanhDo() - diem2.getHoanhDo();
        double y = diem1.getTungDo() - diem2.getTungDo();
        double z = diemKhac1.getHoanhDo() - diemKhac2.getHoanhDo();
        double h = diemKhac1.getTungDo() - diemKhac2.getTungDo();
        if ((x / y) == (z / h)) {
            return true;
        } else {
            return false;
        }
    }
}
