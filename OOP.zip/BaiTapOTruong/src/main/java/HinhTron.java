
import static java.lang.Math.PI;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class HinhTron {

    private double x, y;
    private double banKinh;

    public HinhTron(double x, double y, double banKinh) {
        this.x = x;
        this.y = y;
        this.banKinh = banKinh;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getBanKinh() {
        return banKinh;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setBanKinh(double banKinh) {
        this.banKinh = banKinh;
    }

    public double chuVi() {
        return 2 * PI * this.banKinh;
    }

    public double dienTich() {
        return PI * (Math.pow(this.banKinh, 2));
    }

    public void hienThi() {
        System.out.println("chu vi :" + chuVi());
        System.out.println("dien tich: " + dienTich());
    }

  

    public String viTriTuongDoi(double xDiem, double yDiem) {
        double khoangCach = Math.sqrt(Math.pow(xDiem - x, 2) + Math.pow(yDiem - y, 2));
        if (khoangCach < banKinh) {
            return "nam trong hinh tron";
        } else if (khoangCach == banKinh) {
            return "nam tren duong tron";
        } else {
            return "nam ngoai duong tron";
        }
    }

    public String viTriTuongDoi2DT(HinhTron hinhtronkhac) {
         double khoangCach = Math.sqrt(Math.pow(hinhtronkhac.x - x, 2) + Math.pow(hinhtronkhac.y - y, 2));
   if(khoangCach==0)
   {
       if(banKinh== hinhtronkhac.banKinh)
       {
           return "hai hình tron trung nhau";
       }
       else 
           return "hai hinh tron de len nhau";
   }
   else if(khoangCach <banKinh + hinhtronkhac.banKinh)
   {
       return"hai hinh tron cắt nhau";
       
   }
   else return "hai hinh tron nam xa nhau";
   
    }

}
