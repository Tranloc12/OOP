
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class Diem {

    private int tungDo;
    private int hoanhDo;

    public Diem(int tungDo, int hoanhDo) {
        this.tungDo = tungDo;
        this.hoanhDo = hoanhDo;
    }

    public int getTungDo() {
        return tungDo;
    }

    public int getHoanhDo() {
        return hoanhDo;
    }

    public void setTungDo(int tungDo) {
        this.tungDo = tungDo;
    }

    public void setHoanhDo(int hoanhDo) {
        this.hoanhDo = hoanhDo;
    }

    public void xuatRaDiem() {
        System.out.println("diem A(" + this.hoanhDo + "," + this.tungDo + ")");
    }

    public double khoangCach(Diem diem)
    {
       return  Math.sqrt((Math.pow(this.hoanhDo- diem.hoanhDo,2))+(Math.pow(this.tungDo - diem.tungDo , 2)));
    }
}
