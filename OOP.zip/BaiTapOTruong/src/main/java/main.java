/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        //Diem
        Diem A = new Diem(1, 2);
        A.xuatRaDiem();
        Diem B = new Diem(4, 6);
        B.xuatRaDiem();
        Diem C = new Diem(2, 3);
        Diem D = new Diem(5, 7);
        System.out.println(A.khoangCach(B));
        //DoanThang
        DoanThang dt = new DoanThang(A, B);
        dt.doanThang();
        dt.doDaiDoanThang();
        dt.trungDiem();
        System.out.println("doan thang AB va CD co SS khong " + dt.kiemTraSS(C, D));
        //hinhchunhat
        HinhChuNhat hcn = new HinhChuNhat(A, B);
        hcn.hienThi();
        //hình tròn 
        HinhTron ht = new HinhTron(0, 0, 5);
        ht.hienThi();
        System.out.println("vị tri cua diem (3,4) tuong doi voi hinh tron: " + ht.viTriTuongDoi(3, 4));
        HinhTron ht2= new HinhTron(8,0,3);
        System.out.println("vi tri tuong doi cua hai hinh tron: "+ ht.viTriTuongDoi2DT(ht2));

    }
}
