/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class HinhChuNhat {

    private Diem diemTrai;
    private Diem diemPhai;

    public HinhChuNhat(Diem diemTrai, Diem diemPhai) {
        this.diemTrai = diemTrai;
        this.diemPhai = diemPhai;
    }

    public Diem getDiemTrai() {
        return diemTrai;
    }

    public Diem getDiemPhai() {
        return diemPhai;
    }

    public void setDiemTrai(Diem diemTrai) {
        this.diemTrai = diemTrai;
    }

    public void setDiemPhai(Diem diemPhai) {
        this.diemPhai = diemPhai;
    }

    public double dienTich() {
        double chieuDai = Math.abs(diemPhai.getHoanhDo() - diemTrai.getHoanhDo());
        double chieuRong = Math.abs(diemPhai.getTungDo() - diemTrai.getTungDo());
        return chieuDai * chieuRong;
    }

    public double tinhChuVi() {
        double chieuDai = Math.abs(diemPhai.getHoanhDo() - diemTrai.getHoanhDo());
        double chieuRong = Math.abs(diemPhai.getTungDo() - diemTrai.getTungDo());
        return 2*(chieuDai+chieuRong);
    }

    public void hienThi() {
        System.out.println("dien tich :" + dienTich());
        System.out.println("chu vi:" + tinhChuVi());

    }
    
}
