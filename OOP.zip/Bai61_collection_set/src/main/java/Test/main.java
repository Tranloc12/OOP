/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

import Main.DanhSachSinhVien;
import Main.SinhVien;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DanhSachSinhVien dssv = new DanhSachSinhVien();
        int luaChon = 0;
        do {
            System.out.println("-------MENU------");
            System.out.println("1.them sinh vien vao danh sach ");
            System.out.println("2.in danh sach sinh vien ");
            System.out.println("3.kiem tra danh sach co rong hay khong ");
            System.out.println("4.lay ra so luong sinh vien trong danh sach");
            System.out.println("5.lam rong danh sach sinh vien ");
            System.out.println("6.kiem tra sinh vien co ton tai trong danh sach hay khong dua tren ma sinh vien ");
            System.out.println("7.xoa mot sinh vien ra khoi danh sach dua tren ma sinh vien  ");
            System.out.println("8.tim kiem tat ca sinh vien dua tren Ten duoc nhap tu ban phim");
            System.out.println("9.xuat ra danh sach sinh vien co diem tu cao den thap");
            System.out.println("0.thoat khoi chuong trinh");
            System.out.println("vui long chon chuc nang  ");
            System.out.println(luaChon = sc.nextInt());
            sc.nextLine();
            switch (luaChon) {
                case 1:
                    System.out.println("NHAP MA SINH VIEN: ");
                    String maSinhVien = sc.nextLine();
                    System.out.println("HO VA TEN: ");
                    String hoVaTen = sc.nextLine();
                    System.out.println("NAM SINH: ");
                    int namSinh = sc.nextInt();
                    System.out.println("DIEM TRUNG BINH: ");
                    Float diemTrungBinh = sc.nextFloat();
                    SinhVien sv = new SinhVien(maSinhVien, hoVaTen, namSinh, diemTrungBinh);
                    dssv.themSinhVien(sv);
                    break;
                case 2:
                   dssv.inDanhSachSinhVien();
                    break;
                case 3:
                    System.out.println("Danh sach rong : " + dssv.kiemTraDanhSachRong());
                    break;
                case 4:
                    System.out.println("so luong hien tai: "+ dssv.layRaSoLuong());
                    break;
                case 5:
                    dssv.danhSachRong();
                    break;
                case 6:
                    System.out.println("NHAP MA SINH VIEN: ");
                    String maSinhVien1 = sc.nextLine();
                    SinhVien sv2= new SinhVien(maSinhVien1);
                    System.out.println("kiem tra sinh vien co trong danh sach "+dssv.kiemTraTonTai(sv2));
                    break;
                case 7:
                    System.out.println("nhap ma sinh vien ");
                    String maSinhVien2= sc.nextLine();
                    SinhVien sv3= new SinhVien(maSinhVien2);
                    System.out.println("xoa danh sach sinh vien "+ dssv.xoaSinhVien(sv3));
                    break;
                case 8:
                    System.out.println("nhap ho va ten: ");
                    String hoVaTen1= sc.nextLine();
                    System.out.println("ket qua ");
                    dssv.timSinhVien(hoVaTen1);
                    break;
                case 0:
                    break;
                    
                default:
                    throw new AssertionError();
            }

        } while (luaChon != 0);
    }
}
