/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author admin
 */
public class DanhSachSinhVien {

    private ArrayList<SinhVien> danhSach;

    public DanhSachSinhVien() {
        this.danhSach = new ArrayList<SinhVien>();

    }

    public DanhSachSinhVien(ArrayList<SinhVien> danhSach) {
        this.danhSach = danhSach;
    }

    //thêm danh sách sinh viên 
    public void themSinhVien(SinhVien sv) {
        this.danhSach.add(sv);

    }

    //in danh sách sinh viên 
    public void inDanhSachSinhVien() {
        for (SinhVien sinhVien : danhSach) {
            System.out.println(sinhVien);
        }
    }
    //tạo ra danh sách sinh viên ra màn hình 

    @Override
    public String toString() {
        return "DanhSachSinhVien{" + "danhSach=" + danhSach + '}';
    }

    //kiem tra danh sach có rong hay khong 
    public boolean kiemTraDanhSachRong() {
        return this.danhSach.isEmpty();
    }

    //lay ra  so luong sinh vien trong danh sach 
    public int layRaSoLuong() {
        return this.danhSach.size();
    }
    //ham lam rong danh sach sinh vien 

    public void danhSachRong() {
        this.danhSach.removeAll(danhSach);
    }

    // kiem tra sinh vien co ton tai trong danh sach hay khong 
    public boolean kiemTraTonTai(SinhVien sv) {
        return this.danhSach.contains(sv);
    }

    //xoa 1 sinh vien ra khoi danh sach
    public boolean xoaSinhVien(SinhVien sv) {
        return this.danhSach.remove(sv);

    }

    //tim kiem all sinh vien dau tren Ten 
    public void timSinhVien(String ten) {
        for (SinhVien sinhVien : danhSach) {
            if (sinhVien.getHoVaTen().indexOf(ten) >= 0) {
                System.out.println(sinhVien);
            }
        }
    }
    //sap xep sinh vien có dieemr từ cao den thấp
    //sắp xếp điểm sao cho nó giảm dần 
    
 
  

}
