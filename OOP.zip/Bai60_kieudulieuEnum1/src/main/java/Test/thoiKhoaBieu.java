/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

/**
 *
 * @author admin
 */
public class thoiKhoaBieu {
    private Day thu;
    private Mon cacMonHoc;

    public thoiKhoaBieu(Day thu, Mon cacMonHoc) {
        this.thu = thu;
        this.cacMonHoc = cacMonHoc;
    }

    public Day getThu() {
        return thu;
    }

    public Mon getCacMonHoc() {
        return cacMonHoc;
    }

    public void setThu(Day thu) {
        this.thu = thu;
    }

    public void setCacMonHoc(Mon cacMonHoc) {
        this.cacMonHoc = cacMonHoc;
    }

    @Override
    public String toString() {
        return "thoiKhoaBieu{" + "thu=" + thu + ", cacMonHoc=" + cacMonHoc + '}';
    }
    
}
