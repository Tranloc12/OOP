/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Test;

/**
 *
 * @author admin
 */
public class main {
    public static void main(String[] args) {
        
    
    //Day.
    thoiKhoaBieu tkb = new thoiKhoaBieu(Day.Monday,Mon.CongDan);

        System.out.println(tkb);
}

}