/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai60_kieudulieuenum1;

/**
 *
 * @author admin
 */
public class Bai60_kieudulieuEnum1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
