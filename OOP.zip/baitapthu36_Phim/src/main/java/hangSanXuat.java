/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class hangSanXuat {
    private String hangSanXuat;
    private String quocGia;

    public hangSanXuat(String hangSanXuat, String quocGia) {
        this.hangSanXuat = hangSanXuat;
        this.quocGia = quocGia;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public String getQuocGia() {
        return quocGia;
    }

    public void setHangSanXuat(String hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public void setQuocGia(String quocGia) {
        this.quocGia = quocGia;
    }
    
    
}
