/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {
    
    public static void main(String[] args) {
        ngayChieu ngay1 = new ngayChieu(9, 4, 2024);
        ngayChieu ngay2 = new ngayChieu(10, 4, 22024);
        ngayChieu ngay3 = new ngayChieu(15, 4, 2024);
        hangSanXuat hangSanXuat1 = new hangSanXuat("CGV", "việt nam");
        hangSanXuat hangSanXuat2 = new hangSanXuat("lotte", "việt nam");
        hangSanXuat hangSanXuat3 = new hangSanXuat("BHD", "việt nam");
        boPhim boPhim = new boPhim("phim ma", 2024, hangSanXuat1, 15000, ngay1);
        boPhim boPhim1 = new boPhim("phim hai", 2024, hangSanXuat2, 25000, ngay2);
        boPhim boPhim2 = new boPhim("phim hoat hinh", 2024, hangSanXuat3, 5000, ngay3);
        System.out.println("ss gia 1 re hon 2 " + boPhim.kiemTraGiaVeReHon(boPhim2));
        System.out.println("ss gia 3 re hon 1" + boPhim2.kiemTraGiaVeReHon(boPhim));
        System.out.println("ten hang san xuat cua bo phim " + boPhim.layTenHangSanXuat());
        System.out.println("gia ve con lai sau khi duoc giam tien " + boPhim.giaVeGiamGia(50));
    }
}
