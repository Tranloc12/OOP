/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class boPhim {

    private String tenPhim;
    private int namSanXuat;
    private hangSanXuat hangSanXuat;
    private double giaVe;
    private ngayChieu ngayChieu;

    public boPhim(String tenPhim, int namSanXuat, hangSanXuat hangSanXuat, double giaVe, ngayChieu ngayChieu) {
        this.tenPhim = tenPhim;
        this.namSanXuat = namSanXuat;
        this.hangSanXuat = hangSanXuat;
        this.giaVe = giaVe;
        this.ngayChieu = ngayChieu;
    }

    public String getTenPhim() {
        return tenPhim;
    }

    public int getNamSanXuat() {
        return namSanXuat;
    }

    public hangSanXuat getHangSanXuat() {
        return hangSanXuat;
    }

    public double getGiaVe() {
        return giaVe;
    }

    public ngayChieu getNgayChieu() {
        return ngayChieu;
    }

    public void setTenPhim(String tenPhim) {
        this.tenPhim = tenPhim;
    }

    public void setNamSanXuat(int namSanXuat) {
        this.namSanXuat = namSanXuat;
    }

    public void setHangSanXuat(hangSanXuat hangSanXuat) {
        this.hangSanXuat = hangSanXuat;
    }

    public void setGiaVe(double giaVe) {
        this.giaVe = giaVe;
    }

    public void setNgayChieu(ngayChieu ngayChieu) {
        this.ngayChieu = ngayChieu;
    }

    public boolean kiemTraGiaVeReHon(boPhim phimKhac) {
        return this.giaVe < phimKhac.giaVe;
    }

    public String layTenHangSanXuat() {
        return this.hangSanXuat.getHangSanXuat();
    }

    public double giaVeGiamGia(double x) {
          return this.giaVe*(1-x/100);
    }
}
