/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bai57_cachphanchuoithanhmang;

import java.util.Arrays;

/**
 *
 * @author admin
 */
public class main {
    public static void main(String[] args) {
        String s="xin chao cac ban tui la pêtr";
        String[] a= s.split(" ");
        System.out.println(Arrays.toString(a));
        String[] b= s.split(",");
        System.out.println(Arrays.toString(b));
    }
}
