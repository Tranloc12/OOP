/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai57_cachphanchuoithanhmang;

/**
 *
 * @author admin
 */
public class Bai57_cachphanchuoithanhmang {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
