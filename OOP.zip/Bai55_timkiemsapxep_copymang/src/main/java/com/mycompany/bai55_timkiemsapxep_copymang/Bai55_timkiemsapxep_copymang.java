/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.bai55_timkiemsapxep_copymang;

import java.lang.reflect.Array;
import java.util.Arrays;

/**
 *
 * @author admin
 */
public class Bai55_timkiemsapxep_copymang {

    public static void main(String[] args) {
        int[] a = new int[]{1, 8, 3, 9, 8, 4, 1, 2, 3, 6, 9};
        int[] b = new int[15];
        //
        System.out.println("a ban dau "+Arrays.toString(a));
        //hàm sắp xếp 
        Arrays.sort(a);
        System.out.println("a sau khi sap xep" + Arrays.toString(a));
        //hàm tìm kiếm 
        System.out.println(Arrays.binarySearch(a, 4));
        System.out.println(Arrays.binarySearch(a, -1));
        //hàm điền giá trị 
        Arrays.fill(b,5);
        System.out.println("b sau khi dien gia tri "+ Arrays.toString(b));

    }
}
