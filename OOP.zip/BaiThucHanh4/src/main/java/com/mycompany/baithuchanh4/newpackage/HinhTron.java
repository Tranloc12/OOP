/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

/**
 *
 * @author admin
 */
public class HinhTron extends Hinh {
    private double banKinh;

    public HinhTron(String tenHinh, double banKinh) {
        super(tenHinh);
        this.banKinh = banKinh;
    }

    @Override
    public double tinhDienTich() {
        return Math.PI * banKinh * banKinh;
    }

    @Override
    public double tinhChuVi() {
        return 2 * Math.PI * banKinh;
    }

    @Override
    public String toString() {
        return String.format("HinhTron[tenHinh=%s, dienTich=%.2f, chuVi=%.2f]", 
                tenHinh, tinhDienTich(), tinhChuVi());
    }
}

