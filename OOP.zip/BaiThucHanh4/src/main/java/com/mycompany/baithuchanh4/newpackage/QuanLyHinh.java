/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class QuanLyHinh {
    private List<Hinh> dsHinh;
    public QuanLyHinh()
    {
        dsHinh= new ArrayList<>();
    }
    public void themHinh(Hinh hinh)
    {
        dsHinh.add(hinh);
    }
    public void xoaHinh(String tenHinh)
    {
        dsHinh.remove(tenHinh);
    }
    public void hienThiThongTin()
    {
        dsHinh.forEach(System.out::println);
    }
  
  

    public double tinhDienTichTrungBinh() {
        return dsHinh.stream().mapToDouble(Hinh::tinhDienTich).average().orElse(0);
    }

    public int timHinh(Hinh h) {
        return dsHinh.indexOf(h);
    }
}
