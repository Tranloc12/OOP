/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

import java.util.Objects;

/**
 *
 * @author admin
 */
public abstract class Hinh {
    String tenHinh;

    public Hinh(String tenHinh) {
        this.tenHinh = tenHinh;
    }

  
    public abstract double tinhDienTich();
   
    public abstract double tinhChuVi();


    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hinh other = (Hinh) obj;
        return Objects.equals(this.tenHinh, other.tenHinh);
    }

    /**
     * @return the tenHinh
     */
    public String getTenHinh() {
        return tenHinh;
    }

    /**
     * @param tenHinh the tenHinh to set
     */
    public void setTenHinh(String tenHinh) {
        this.tenHinh = tenHinh;
    }

    @Override
    public String toString() {
        return String.format("%s[tenHinh=%s, dienTich=%.2f, chuVi=%.2f]", 
                getClass().getSimpleName(), tenHinh, tinhDienTich(), tinhChuVi());
    }
   
    
}
