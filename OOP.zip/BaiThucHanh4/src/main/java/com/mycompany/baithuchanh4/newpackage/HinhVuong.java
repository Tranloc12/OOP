/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

/**
 *
 * @author admin
 */
public class HinhVuong extends Hinh {
    private double canh;

    public HinhVuong(String tenHinh, double canh) {
        super(tenHinh);
        this.canh = canh;
    }

    @Override
    public double tinhDienTich() {
        return canh * canh;
    }

    @Override
    public double tinhChuVi() {
        return 4 * canh;
    }

    @Override
    public String toString() {
        return String.format("HinhVuong[tenHinh=%s, dienTich=%.2f, chuVi=%.2f]", 
                tenHinh, tinhDienTich(), tinhChuVi());
    }
}

