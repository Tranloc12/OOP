/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

/**
 *
 * @author admin
 */
public class Ellipse extends Hinh{
    private double trucLon;
    private double trucNho;
    public Ellipse(String ten) {
        super(ten);
    }

    public Ellipse(double trucLon, double trucNho, String ten) {
        super(ten);
        this.trucLon = trucLon;
        this.trucNho = trucNho;
    }

    /**
     * @return the trucLon
     */
    public double getTrucLon() {
        return trucLon;
    }

    /**
     * @param trucLon the trucLon to set
     */
    public void setTrucLon(double trucLon) {
        this.trucLon = trucLon;
    }

    /**
     * @return the trucNho
     */
    public double getTrucNho() {
        return trucNho;
    }

    /**
     * @param trucNho the trucNho to set
     */
    public void setTrucNho(double trucNho) {
        this.trucNho = trucNho;
    }
    public void Ellipe(double lon, double be){
        if(this.trucLon == this.trucNho)
        {
            System.out.println("Ellipse");
        }
        else
        {
            System.out.println("khong phai hinh Ellipse");
        }
    }
    public double tinhDienTich()
    {
        return this.trucLon - this.trucNho;
    }
    
    public double tinhChuVi()
    {
        return this.trucLon + this.trucNho;
    }

    @Override
    public String toString() {
        return String.format("Ellipse[tenHinh=%s, dienTich=%.2f, chuVi=%2.f]",getClass().getSimpleName(), tenHinh, tinhDienTich(), tinhChuVi());
    }
    
}
