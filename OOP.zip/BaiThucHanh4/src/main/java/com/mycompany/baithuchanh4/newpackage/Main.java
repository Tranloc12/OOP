/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.baithuchanh4.newpackage;

/**
 *
 * @author admin
 */
public class Main {

    public static void main(String[] args) {
        QuanLyHinh qlh = new QuanLyHinh();
        qlh.themHinh(new HinhChuNhat(3, 4, "HCN1"));
        qlh.themHinh(new Ellipse(3, 4, "Ellipse"));
        qlh.themHinh(new TamGiac(3, 3, 3, "Tam Giác"));
        qlh.themHinh(new HinhVuong("HV1", 5));
        System.out.println("Danh sach cac Hinh: ");
        qlh.hienThiThongTin();
        
    }
}
