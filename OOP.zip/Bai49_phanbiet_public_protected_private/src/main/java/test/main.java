/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import code.Infor;

/**
 *
 * @author admin
 */
public class main {
    private Infor infor;
    public void method()
    {
    // this.infor.a=>khong truy xuat duoc
        this.infor.b =2;
    }
}
