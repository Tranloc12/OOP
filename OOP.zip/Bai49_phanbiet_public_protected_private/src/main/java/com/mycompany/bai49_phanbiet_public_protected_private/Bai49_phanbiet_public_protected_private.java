/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai49_phanbiet_public_protected_private;

/**
 *
 * @author admin
 */
public class Bai49_phanbiet_public_protected_private {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
