/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package code;

/**
 *
 * @author admin
 */
public class Infor {
    private int a;
     int b;
      protected int c;
      public int d;
      
      public void method()
      {
          this.a= 1;
          this.b= 2;
      }
}
