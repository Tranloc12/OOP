/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai45_abstract;

/**
 *
 * @author admin
 */
public class Bai45_abstract {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
