/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author admin
 */
public class HinhChuNhat extends Hinh {
    private double chieuRong, chieuCao;

    public HinhChuNhat(double chieuRong, double chieuCao, ToaDo toaDo) {
        super(toaDo);
        this.chieuRong = chieuRong;
        this.chieuCao = chieuCao;
    }

    public double getChieuRong() {
        return chieuRong;
    }

    public double getChieuCao() {
        return chieuCao;
    }

    public void setChieuRong(double chieuRong) {
        this.chieuRong = chieuRong;
    }

    public void setChieuCao(double chieuCao) {
        this.chieuCao = chieuCao;
    }

    @Override
    public double tinhDienTich() {

return this.chieuCao *this.chieuRong;    }
    
}
