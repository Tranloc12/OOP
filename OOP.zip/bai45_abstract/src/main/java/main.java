/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        ToaDo td1 = new ToaDo(0, 5);
        ToaDo td2 = new ToaDo(0, 10);
        ToaDo td3 = new ToaDo(0, 4);
        //lớp trừu tượng không gọi constructor được tại
//        Hinh h = new Hinh(td1);
//        Hinh h1 = new Hinh(td2);
//        Hinh h2 = new Hinh(td3);
        Hinh h1 = new Diem(td1);

        System.out.println("DT1" + h1.tinhDienTich());


    }
}
