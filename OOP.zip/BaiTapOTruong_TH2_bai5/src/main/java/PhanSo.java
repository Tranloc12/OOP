/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class PhanSo {
    private double tuSo;
    private double mauSo;
    

    public PhanSo(double tuSo, double mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }
   

    public double getTuSo() {
        return tuSo;
    }

    public double getMauSo() {
        return mauSo;
    }

    public void setTuSo(double tuSo) {
        this.tuSo = tuSo;
    }

    public void setMauSo(double mauSo) {
        this.mauSo = mauSo;
    }
    
}
