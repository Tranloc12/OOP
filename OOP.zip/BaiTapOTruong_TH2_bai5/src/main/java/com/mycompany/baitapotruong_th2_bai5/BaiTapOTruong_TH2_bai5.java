/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.baitapotruong_th2_bai5;

/**
 *
 * @author admin
 */
public class BaiTapOTruong_TH2_bai5 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
