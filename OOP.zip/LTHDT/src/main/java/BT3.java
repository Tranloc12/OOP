/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author admin
 */
import java.util.Scanner;
public class BT3 
{
    
    public static void main(String args[]) 
    {
        Scanner scanner= new Scanner(System.in);
                System.out.println("vui long nhap chuoi co email" );
                String chuoi= scanner.nextLine();
                 scanner.nextLine();
                //xử lí cat chuoi 
                String[] x = chuoi.split("@");
                System.out.print("vui long xuat chuoi: "+ x[0]);   
        }
    
    
    public static void main1(String agrs[])
    {
        Scanner scanner= new Scanner(System.in);
        System.out.println("vui long nhap chuoi co ki tu hoa" );
        String chuoi= scanner.nextLine();
        int count =0;
        for(int i=0;i<chuoi.length();i++)
        {
            if(Character.isUpperCase(chuoi.charAt(i)))
            {
                count++;
            }
        }
        System.out.print("in: "+ count);   
    }
    //D)
      public static void main2(String agrs[])
      {
          Scanner scanner= new Scanner(System.in);
          String chuoi= scanner.nextLine();
          //chuyen khoang cach dau phảy về thanh chuoi
          String[] words= chuoi.split("[\\s,;]+");
          //dem tu
          int count = words.length;
          System.out.print("In ra"+count );
          //tim tu dai nhat
          String tudainhat="";
          for(String word : words)
          {if(word.length()>tudainhat.length())
          { tudainhat=word;
              }
          }
          System.out.print("tu dai nhat"+tudainhat);
          
      }
      //E
       public static void main3(String agrs[])
       {
         Scanner scanner= new Scanner(System.in);
         String chuoi = scanner.nextLine();
         chuoi= chuoi.trim().replaceAll("[\\s,;]+", " ");
         String[] words= chuoi.split(" ");
         for(String word :words)
         {
             if(!word.isEmpty())
             {
                 String chuanhoa=word.substring(0,1).toUpperCase() + word.substring(1).toLowerCase();
             }
         }
         System.out.print("IN RA : "+ chuoi);
    
}
}