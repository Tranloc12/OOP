/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
import java.util.Scanner;

public class BT5tainha {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
//        System.out.println("Ho va ten");
//        String hoVaTen = sc.nextLine();
//        System.out.println("Ma sinh vien");
//        long maSinhVien = sc.nextLong();
//        System.out.println("nhap vao diem thi");
//        float diemthi = sc.nextFloat();
//        System.out.println("IN RA " + hoVaTen + maSinhVien + diemthi);
//        System.out.println("nhap so ");
//        int a = sc.nextInt();
//        String ketqua = (a % 2 == 0) ? "chẵn" : "lẻ";
//        System.out.println("IN RA " + a + " la " + ketqua);
//        System.out.println("nhap so double");
//        double a1 = sc.nextDouble();
//        System.out.println("nhap so double");
//        double a2 = sc.nextDouble();
//        //hàm trị tuyetj đôi 
//        System.out.println("|a1|" + Math.abs(a1));
//        System.out.println("min(a1,a2)" + Math.min(a1, a2));
//        System.out.println("max(a1,a2)" + Math.max(a1, a2));
//        System.out.println("ceil(a1)" + Math.ceil(a1));
//        System.out.println("sqrt(a1)" + Math.sqrt(a1));
        // tính chu vi 
//        double r, dientich, chuvi;
//        System.out.println("nhap ban kinh");
//        r = sc.nextDouble();
//
//        chuvi = 2 * Math.PI * r;
//        System.out.println("CHU VI " + chuvi);
//        System.out.println("CHU VI " + Math.round(chuvi * 100.0) / 100);

        //câu lệnh IF ELSE;
//        int n;
//        n = sc.nextInt();
//        if (n % 2 == 0) {
//            System.out.println("chẵn");
//        }
//        System.out.println("lẻ");
//         bài tập giải phương trình bậc nhất 
        int a, b, x;
        a = sc.nextInt();
        b = sc.nextInt();
        if (a == 0) {
            if (b == 0) {
                System.out.println("phương trình vo so nghiem");
            } else {
                System.out.println("pt vo nghiem");
            }

        }
        else 
        {  x = -b / a;
        
        System.out.println("co nghiem x=" + x);

    }
    }
}
