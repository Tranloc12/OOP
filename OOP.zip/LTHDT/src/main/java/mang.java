
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class mang {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int[] mang1= new int[10];
        double[] mang2= new double[]{1,2,3,4,5,6};
        for(int i=0;i<mang1.length;i++)
        { 
            System.out.println("vui long nhap mang thu "+i );
            mang1[i]= sc.nextInt();
           
        }
        double tong=0;
        for(int i=0;i<mang1.length;i++)
        {
            tong+= mang1[i];
            
        }
        System.out.println("tong =" +tong);
        for(int i=0;i<mang2.length;i++)
        {
             System.out.println("nhap mang thu " +i+ " = "+ mang2[i]);
             
        }
    }
}
