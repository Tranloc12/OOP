/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lthdt;

/**
 *
 * @author admin
 */
public class LTHDT {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
