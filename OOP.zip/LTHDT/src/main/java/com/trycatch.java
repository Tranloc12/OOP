/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class trycatch {

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int n=0;
        try {
            System.out.println("vui long nhap");
             n= sc.nextInt();
        } catch (Exception e) {
            System.out.println("nhap sai vui long nhap lai");
        } finally {
            System.out.println("hoan thanh");
        }
        System.out.println("gia tri n"+n);
    }
  
}
