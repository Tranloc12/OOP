/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com;

/**
 *
 * @author admin
 */
//THUỘC TÍNH(BIẾN)
    //con người có họ và tên , ngày sinh , địa chỉ 
//HÀNH VI (HÀM)
    //hành động: ăn , nghỉ ngơi , ca hát , tập thể dục 
// public : công cộng 
//abstract



//hai kiểu dữ liệu : nguyên thủy và lớp 
// ví dụ : MyClass myobj= new MyClass()
//         MyParent myobj = new MyClass();
////////////////////////////////////////////
// taoj ra một class: ngày tháng date
//trong date có các dữ liệu : day, mont , year 
//trong date phương thức :in ra màn hình ngày tháng năm
public class Xaydunglop {

    public static void main(String[] args) {

    }
}
