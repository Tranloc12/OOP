/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com;

/**
 *
 * @author admin
 */
public class getter_setter {

    private int day;
    private int month;
    private int year;

    public getter_setter(int d, int m, int y) {
        if (day >= 1 && day <= 31) {
            this.day = day;
        } else {
            this.day = 1;
        }
        if (month >= 1 && month <= 12) {
            this.month = m;
        } else {
            this.month = 1;
        }
        if (year >= 0) {
            this.year = y;
        } else {
            this.year = 1;
        }
    }
}
