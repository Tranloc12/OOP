/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class NewClass {
    public static void main(String[] args) {
        Bai31 hd= new Bai31("trung nguyên",100,1.5);
        System.out.println("tổng tiên : " + hd.tinhTongTien());
    }
}
