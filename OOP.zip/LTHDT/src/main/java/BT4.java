/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
 import java.util.Scanner;
public class BT4 {
 public static void main(String agrs[])
 {
         Scanner scanner= new Scanner(System.in);
         System.out.print("vui long nhap so luong so");
         int n = scanner.nextInt();
         int[] so1= new int[n];
         for(int i=0;i<n;i++)
         {
             System.out.print("so nguyen thu a["+i+"] = ");
             so1[i]= scanner.nextInt();
         }
        for(int i=0;i<n;i++)
        {
         if(kiemtrasonguyento(so1[i]))
         {
             System.out.print(so1[i]+" la so nguyen to ");
         }
         else
         {
             System.out.print(so1[i]+"khong phải la so nguyen to ");
         }
         }
 }
 public static boolean kiemtrasonguyento(int n)
 {
        if (n<2)
        {
            return false;
        }
        for(int i= 2;i<=Math.sqrt(n);i++)
        {
           if(n%i==0)
           {
               return false;
           }
        }
        return true;
 }      
}      
 
    

