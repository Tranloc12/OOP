/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class getter_setter_1 {

    public static void main(String[] args) {

        getter_setter md = new getter_setter(31, 1, 2021);
        System.out.println("xuat ra " + md.toString());
        md.setDay(30);
        System.out.print("xuat ra " + md.getDay());

    }
}
