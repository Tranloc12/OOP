/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class getter_setter {

    private int day;
    private int month;
    private int year;

    public getter_setter(int d, int m, int y) {
        if (day >= 1 && day <= 31) {
            this.day = d;
        } else {
            this.day = 1;
        }
        if (month >= 1 && month <= 12) {
            this.month = m;
        } else {
            this.month = m;
        }
        if (year >= 0) {
            this.year = y;
        } else {
            this.year = 1;
        }

    }

    public int getDay() {
        return this.day;
    }

    public void setDay(int d) {
        if (day >= 1 && day <= 31) {
            this.day = d;
        } else {
            this.day = 1;
        }

    }
    @Override
    public String toString() 
            {
              return this.day+"/"+this.month+"/"+ this.year ;  
            }
}
