
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
//vòng lặp for trong java
public class baitapthu21 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String nhiphan= "";
        outer: for(int i=0;i<n;i++)
        while (n > 0) {
            nhiphan= (n%2) +nhiphan;
            n=n/2;
            break outer;
                    
        }
        System.out.println(nhiphan );
    }

}
