/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author admin
 */
import java.util.Scanner;

public class BT1 {

    public static void main(String[] args) {
        // Sinh số ngẫu nhiên từ 1 đến 100
        int randomNumber = (int) (Math.random() * 100) + 1;

        // Khởi tạo đối tượng Scanner để nhận dữ liệu từ người dùng
        Scanner scanner = new Scanner(System.in);

        // Biến để lưu số dự đoán của người dùng
        int guessedNumber;

        // Vòng lặp để người dùng nhập dự đoán và kiểm tra
        do {
            // Nhập số dự đoán từ người dùng
            System.out.print("so ban doan: ");
            guessedNumber = scanner.nextInt();

            // Kiểm tra số dự đoán của người dùng và đưa ra thông báo phù hợp
            if (guessedNumber < randomNumber) {
                System.out.println("so ban doan nho hon");
            } else if (guessedNumber > randomNumber) {
                System.out.println("so ban doan lon hon");
            } else {
                System.out.println("ban da doan dung ");
            }
        } while (guessedNumber != randomNumber);

        // Đóng đối tượng Scanner
        scanner.close();
    }
}
