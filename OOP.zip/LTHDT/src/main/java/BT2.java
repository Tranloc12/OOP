/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

/**
 *
 * @author admin
 */
import java.util.Scanner;

public class BT2 {

    public static int tinhToan(int[] mang, int x) {
        int result = 0;
        for (int i = 0; i < mang.length; i++) {
            result += mang[i] * Math.pow(x, i);
        }
        return result;
    }

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("nhap da thuc bac ");
        int n = scanner.nextInt();
        int[] mang = new int[n + 1];
        System.out.print("nhap he so cua da thuc tu hang tu 0 den hang tu " + n + " ");
        for (int i = 0; i <= n; i++) {
            System.out.println("nhap he so a" + i + ":  ");
            mang[i] = scanner.nextInt();
        }
        System.out.print("nhap gia tri cua x: ");
        int x = scanner.nextInt();
        int result = tinhToan(mang, x);
        System.out.print("gia tri cua da thuc tai x " + x + "=" + result);
        scanner.close();

    }

}
