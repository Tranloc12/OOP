
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class Diem {

// cách 1
//    public static void hienthi(int x1, int y1, int x2, int y2) {
//
//        System.out.println("xuat ra tung do " + x1);
//        System.out.println("xuat ra hoanh do " + y1);
//        System.out.println("co toa do A(" + x1 + "," + y1 + ")");
//        System.out.println("xuat ra tung do " + x2);
//        System.out.println("xuat ra hoanh do " + y2);
//        System.out.println("co toa do B(" + x2 + "," + y2 + ")");
//
//    }
//
//    public static double binhphuong(double num) {
//        return num * num;
//    }
//
//    public static double tinhKhoangCach(int x1, int y1, int x2, int y2) {
//        return Math.sqrt(binhphuong(x1 - x2) + binhphuong(y1 - y2));
//
//    }
//
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("vui long nhap tung do: ");
//        int x = sc.nextInt();
//        System.out.println("vui long nhap hoanh do: ");
//        int y = sc.nextInt();
//        System.out.println("vui long nhap tung do: ");
//        int x2 = sc.nextInt();
//        System.out.println("vui long nhap hoanh do: ");
//        int y2 = sc.nextInt();
//        hienthi(x, y, x2, y2);
//        System.out.println("khoang cach " + tinhKhoangCach(x, y, x2, y2));
//
//    }
    //CÁCH 2
    //thuộc tính hoành độ và tung dô 
    private double hoanhDo;
    private double tungDo;

    //ơhuonwg thức khởi tạo 
    public Diem(double hoanhDo, double tungDo) {
        this.hoanhDo = hoanhDo;
        this.tungDo = tungDo;

    }

    //setter và getter 
    public double setHoanhDo() {
        return hoanhDo;
    }

    public void setHoanhDo(double hoanhDo) {
        this.hoanhDo = hoanhDo;
    }

    public double getTungDo() {
        return tungDo;
    }

    public void getTungDo(double tungDo) {
        this.tungDo = tungDo;
    }

    //phương thức hiển thị thông tin điểm 
    public void hienThiThongTin() {
        System.out.println("Hoanh Do " + hoanhDo);
        System.out.println("Tung DO " + tungDo);
    }

    //phương thức tính khoảng cách
    public static double tinhKhoangCach(Diem diem1, Diem diem2) {
        double khoangcach = Math.sqrt(Math.pow(diem2.hoanhDo - diem1.hoanhDo, 2) + Math.pow(diem2.tungDo - diem1.tungDo, 2));
        return khoangcach;
    }

    public static void main(String[] args) {
        Diem diemA = new Diem(3, 4);
        System.out.println("tọa độ điểm A");

        diemA.setHoanhDo(5);
        diemA.getTungDo(6);
        diemA.hienThiThongTin();
        Diem diemB = new Diem(6, 8);
        System.out.println("tọa dộ điểm B");
        diemB.hienThiThongTin();
        double khoangcachAB = Diem.tinhKhoangCach(diemA, diemB);
        System.out.println(khoangcachAB);
    }
}
