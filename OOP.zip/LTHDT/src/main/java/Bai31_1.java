/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Bai31_1 {
    public static void main(String[] args) {
        Bai31 hd= new Bai31("trung nguyên ",100,2.5);
        System.out.println("tong tien: "+hd.tinhTongTien());
        System.out.println("kiem tra khoi luong lon hon 2 " + hd.kiemTraKhoiLuongLonHon(2));
        System.out.println("kiemtra tien co lon hon 500 không "+hd.kiemTraTongTienLonHon500(200));
        System.out.println("giam gia tien con "+ hd.giamGia(30));
    }
}
