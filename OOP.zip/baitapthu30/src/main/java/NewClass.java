/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class NewClass {
    public static void main(String[] args) {
        int d;
        MyDate md= new MyDate(25,12,2004);
        md.printDay();
        md.printMonth();
        md.printYear();
        md.printall();
    }
}
