/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class MyDate {

    private int day;
    private int month;
    private int year;

    //contructor
    public MyDate(int d, int m, int y) {
        this.day = d;
        this.month = m;
        this.year = y;
    }

    public void printDay() {
        System.out.println("Day " + this.day);
    }

    public void printMonth() {
        System.out.println("month " + this.month);

    }

    public void printYear() {
        System.out.println("year " + this.year);

    }

    public void printall() {
        System.out.println("Date " + this.day + "-" + this.month);

    }

}
