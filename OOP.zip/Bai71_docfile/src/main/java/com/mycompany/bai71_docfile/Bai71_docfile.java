/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai71_docfile;

import java.io.PrintWriter;

/**
 *
 * @author admin
 */
public class Bai71_docfile {

    public static void main(String[] args) {
     try{  PrintWriter pw = new PrintWriter("C:\\Users\\admin\\Documents\\NetBeansProjects\\Bai71_docfile\\src\\main\\java");
        pw.println("xin chao minh la A");
        pw.print("du lieu");
        pw.print(3.14);
        pw.print("so PI");
        Students st= new Students(100,"nguyen Van A");
        pw.print(st);
        pw.flush();
        pw.close();
     }
     catch (Exception e){
         e.printStackTrace();
     }
    }
}
