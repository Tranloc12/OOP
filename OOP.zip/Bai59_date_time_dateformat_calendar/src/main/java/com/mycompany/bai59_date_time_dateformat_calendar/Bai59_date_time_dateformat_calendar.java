/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai59_date_time_dateformat_calendar;

/**
 *
 * @author admin
 */
public class Bai59_date_time_dateformat_calendar {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
