
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class date {

    public static void main(String[] args) {

        //timeMilies -> tính toán thời gian làm việc cảu vòng lặp 
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < 100; i++) {
            System.out.println("TEST ");
        }
        long t2 = System.currentTimeMillis();
        System.out.println("truoc khi chay for: " + t1);
        System.out.println("sau khi chay for: " + t2);
        System.out.println("thoi gian: " + (t2 - t1) + "s");
        //timeUnits tính giờ trong khoảng thời gian chuyển sang giây
        System.out.println("3000 nam = " + TimeUnit.DAYS.toSeconds(3000 * 365) + "s");
        System.out.println("3000 nam = " + TimeUnit.HOURS.toSeconds(25) + "s");
        //Date

        Date d = new Date(System.currentTimeMillis());

        System.out.println(d.getDay() + "/" + d.getMonth() + 1 + "/" + d.getYear() + 1900);
        ///calendar
        Calendar ca = Calendar.getInstance();
        System.out.println(ca.get(Calendar.DATE) + "-" + (ca.get(Calendar.MONTH) + 1) + "-" + ca.get(Calendar.YEAR));

        ca.add(Calendar.HOUR, 30);
        System.out.println(ca.get(Calendar.DATE) + "-" + (ca.get(Calendar.MONTH) + 1) + "-" + ca.get(Calendar.YEAR));
        
        ca.add(Calendar.DATE, 14);
                System.out.println(ca.get(Calendar.DATE)+"-"+(ca.get(Calendar.MONTH)+1)+"-"+ca.get(Calendar.YEAR));

         //DateFormat
         DateFormat df= new SimpleDateFormat();
         System.out.println(df.format(df));
         df= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ");
         System.out.println(df.format(d));
                
                
                
    }

}
