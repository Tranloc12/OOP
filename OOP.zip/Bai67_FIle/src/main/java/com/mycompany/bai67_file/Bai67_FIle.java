/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai67_file;

/**
 *
 * @author admin
 */
public class Bai67_FIle {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
