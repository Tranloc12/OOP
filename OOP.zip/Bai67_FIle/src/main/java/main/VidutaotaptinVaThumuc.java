/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.io.File;

/**
 *
 * @author admin
 */
public class VidutaotaptinVaThumuc {
    public static void main(String[] args) {
        //lưu ý 
        //\\  | ví dụ :" C:\\thu muc 1\\thu muc\\ ten tap'tin.xxx";
        File folder1= new File("C:\\Users\\admin\\Documents\\NetBeansProjects\\Bai67_FIle");
        System.out.println("kiem tra có ton tai khong: "+ folder1.exists());
        // tạo thư mục 
        // phương thức mkdir()
        File d1= new File("C:\\Users\\admin\\Documents\\NetBeansProjects\\Bai67_FIle\\diretory");
        d1.mkdir();
        //tạo nhiều thư mục cùng lúc là mkdirs()
        File d2= new File("C:\\Users\\admin\\Documents\\NetBeansProjects\\Bai67_FIle\\mewo");
        d1.mkdirs();
        //tạo tập tin (có phần mở rộng: .exe,txt, doc, xls
        File file1= new File("C:\\Users\\admin\\Documents\\NetBeansProjects\\Bai67_FIle\\vidu1");
        try {
            file1.createNewFile();
        } catch (Exception e) {
            //khong co quyền tạo tệp tin 
            //ổ cứng đầy 
            //đường dẫn bị sai
            e.printStackTrace();
        }
    }
}
