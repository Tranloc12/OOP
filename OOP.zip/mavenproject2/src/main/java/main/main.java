/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.Arrays;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author admin
 */
public class main {

    private Map<String, String> data = new TreeMap<String, String>();

    public String themTu(String tuKhoa, String yNghia) {
        return this.data.put(tuKhoa, yNghia);

    }

    public String xoaTu(String tuKhoa) {
        return this.data.remove(tuKhoa);
    }

    public String traTu(String tuKhoa) {
        String ketQua = this.data.get(tuKhoa);
        return ketQua;
    }

    public void inTuKhoa() {
        Set<String> tapHopTuKhoa = this.data.keySet();
        System.out.println(Arrays.toString(tapHopTuKhoa.toArray()));
    }

    public int laySoLuong() {
        return this.data.size();

    }

    public void xoaALL() {
        this.data.clear();
    }

    public static void main(String[] args) {
        main m = new main();
        int luaChon = 0;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("----------------");
            System.out.println("------Menu-----");
            System.out.println("tra từ dien anh - viet:\n" + "1.them tu (tukhoa, ynghia)\n" + "2.xoa tu\n" + "3tim y nghia cua tu khoa -tra tu\n" + "4in ra danh sach tu khoa\n" + "5in ra so luong\n " + "6in all\n");
            System.out.println("vui long chon ");
            luaChon = sc.nextInt();
            sc.nextLine();
            switch (luaChon) {
                case 1:
                    System.out.println("nhpa vao tu khoa: ");
                    String tuKhoa = sc.nextLine();
                    System.out.println("nhap vao y nghia: ");
                    String yNghia = sc.nextLine();
                    m.themTu(tuKhoa, yNghia);
                    break;
                case 2:
                    System.out.println("nhap vao tu khoa: ");
                    String tuKhoa1 = sc.nextLine();
                    m.xoaTu(tuKhoa1);
                    break;
                case 3:
                    System.out.println("nhap vao tu khoa: ");
                    String tuKhoa2 = sc.nextLine();
                    System.out.println("y nghia: ");
                     m.traTu(tuKhoa2);
                    break;
                case 4:
                    m.inTuKhoa();
                    break;
                case 5:
                    System.out.println("so luong tu: " + m.laySoLuong());
                    break;
                case 6:
                    m.xoaALL();
                    break;
                default:
                    throw new AssertionError();
            }
        } while (luaChon != 0);

    }
}
