/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bai60_kieudulieuenum;

/**
 *
 * @author admin
 */
public class Bai60_kieudulieuEnum {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
