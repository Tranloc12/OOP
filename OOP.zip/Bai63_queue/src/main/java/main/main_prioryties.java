/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.PriorityBlockingQueue;

/**
 *
 * @author admin
 */
public class main_prioryties {

    public static void main(String[] args) {
        Queue<String> danhSachSv = new PriorityQueue<String>();
        danhSachSv.offer("A");
        danhSachSv.offer("B");
        while (true) {
            //lấy ra và xóa
            String ten = danhSachSv.poll();
            if (ten == null) {
                break;
            }
            //peek => lấy ra nhưng không xóa ;
            System.out.println(ten);
        }

    }

}
