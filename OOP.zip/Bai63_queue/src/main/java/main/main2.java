/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Queue;

/**
 *
 * @author admin
 */
public class main2 {

    public static void main(String[] args) {

        Deque<String> danhSachSv = new ArrayDeque<String>();
        danhSachSv.offer("A");
        danhSachSv.offer("B");
        danhSachSv.offerLast("TITV4");
        danhSachSv.offerFirst("TITV 0");
        while (true) {
            //lấy ra và xóa
            String ten = danhSachSv.poll();
            if (ten == null) {
                break;
            }
            //peek => lấy ra nhưng không xóa ;
            System.out.println(ten);
        }

    }
}
